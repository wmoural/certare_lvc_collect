import QtQuick
import org.qfield.core

Item {
    id: preview

    // QgsQuickMapCanvas/QfMapCanvas retornado por iface.mapCanvas().
    property var mapCanvas: null
    property var tracker: null
    property bool appVisible: true
    property color fallbackColor: "#00ACC1"

    readonly property color lineColor: {
        if (tracker && tracker.buttonConfig && tracker.buttonConfig.cor) {
            return tracker.buttonConfig.cor;
        }
        return fallbackColor;
    }

    // Este componente não ocupa espaço no layout do plugin. O Canvas é
    // visualmente reparentado para o próprio mapa e não captura toques.
    width: 0
    height: 0
    visible: true

    function requestPreviewPaint() {
        if (trackCanvas) trackCanvas.requestPaint();
    }

    Canvas {
        id: trackCanvas
        parent: preview.mapCanvas ? preview.mapCanvas : preview
        anchors.fill: parent
        z: 7000
        visible: preview.appVisible && preview.mapCanvas !== null && preview.tracker !== null && preview.tracker.active
        opacity: 0.95

        onPaint: {
            var ctx = getContext("2d");
            ctx.clearRect(0, 0, width, height);

            if (!preview.mapCanvas || !preview.tracker || !preview.tracker.active) return;
            var pts = preview.tracker.points || [];
            if (pts.length === 0) return;

            var mapSettings = preview.mapCanvas.mapSettings;
            if (!mapSettings) return;

            var screenPts = [];
            for (var i = 0; i < pts.length; i++) {
                var p = pts[i];
                var wgsPoint = QfGeometryUtils.point(Number(p.lon), Number(p.lat));
                var mapPoint = QfGeometryUtils.reprojectPoint(
                    wgsPoint,
                    QfCoordinateReferenceSystemUtils.wgs84Crs(),
                    mapSettings.destinationCrs
                );
                var sp = mapSettings.coordinateToScreen(mapPoint);
                screenPts.push(sp);
            }

            if (screenPts.length >= 2) {
                // Contorno escuro para manter a linha visível sobre qualquer mapa.
                ctx.beginPath();
                ctx.moveTo(screenPts[0].x, screenPts[0].y);
                for (var j = 1; j < screenPts.length; j++) {
                    ctx.lineTo(screenPts[j].x, screenPts[j].y);
                }
                ctx.lineCap = "round";
                ctx.lineJoin = "round";
                ctx.strokeStyle = "rgba(0,0,0,0.65)";
                ctx.lineWidth = 8;
                ctx.stroke();

                ctx.beginPath();
                ctx.moveTo(screenPts[0].x, screenPts[0].y);
                for (var k = 1; k < screenPts.length; k++) {
                    ctx.lineTo(screenPts[k].x, screenPts[k].y);
                }
                ctx.strokeStyle = preview.lineColor;
                ctx.lineWidth = 5;
                ctx.stroke();
            }

            // Mesmo com apenas uma amostra, mostra imediatamente onde o tracking começou.
            var last = screenPts[screenPts.length - 1];
            ctx.beginPath();
            ctx.arc(last.x, last.y, 6, 0, Math.PI * 2);
            ctx.fillStyle = preview.lineColor;
            ctx.fill();
            ctx.strokeStyle = "rgba(0,0,0,0.75)";
            ctx.lineWidth = 2;
            ctx.stroke();
        }
    }

    Connections {
        target: preview.tracker
        enabled: preview.tracker !== null
        ignoreUnknownSignals: true

        function onPointsChanged() { preview.requestPreviewPaint(); }
        function onActiveChanged() { preview.requestPreviewPaint(); }
        function onButtonConfigChanged() { preview.requestPreviewPaint(); }
    }

    // Também redesenha durante pan/zoom/rotação do mapa. É leve e só roda
    // enquanto o rastreamento correspondente estiver ativo.
    Timer {
        interval: 200
        repeat: true
        running: preview.appVisible && preview.tracker !== null && preview.tracker.active
        onTriggered: preview.requestPreviewPaint()
    }
}
