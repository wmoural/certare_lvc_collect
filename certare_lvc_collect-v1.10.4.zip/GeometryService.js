.pragma library

var EARTH_RADIUS_M = 6371008.8;

function rad(graus) {
    return graus * Math.PI / 180.0;
}

function distanciaM(a, b) {
    var lat1 = rad(a.lat);
    var lat2 = rad(b.lat);
    var dLat = lat2 - lat1;
    var dLon = rad(b.lon - a.lon);
    var s1 = Math.sin(dLat / 2.0);
    var s2 = Math.sin(dLon / 2.0);
    var h = s1 * s1 + Math.cos(lat1) * Math.cos(lat2) * s2 * s2;
    return 2.0 * EARTH_RADIUS_M * Math.atan2(Math.sqrt(h), Math.sqrt(Math.max(0.0, 1.0 - h)));
}

function _xyMetros(p, latRefRad) {
    return {
        x: EARTH_RADIUS_M * rad(p.lon) * Math.cos(latRefRad),
        y: EARTH_RADIUS_M * rad(p.lat)
    };
}

function _distanciaPontoSegmentoM(p, a, b) {
    var latRef = rad((p.lat + a.lat + b.lat) / 3.0);
    var pp = _xyMetros(p, latRef);
    var aa = _xyMetros(a, latRef);
    var bb = _xyMetros(b, latRef);
    var vx = bb.x - aa.x;
    var vy = bb.y - aa.y;
    var wx = pp.x - aa.x;
    var wy = pp.y - aa.y;
    var vv = vx * vx + vy * vy;
    if (vv === 0) {
        return Math.sqrt(wx * wx + wy * wy);
    }
    var t = Math.max(0, Math.min(1, (wx * vx + wy * vy) / vv));
    var dx = pp.x - (aa.x + t * vx);
    var dy = pp.y - (aa.y + t * vy);
    return Math.sqrt(dx * dx + dy * dy);
}

function _rdp(pontos, toleranciaM) {
    if (pontos.length <= 2) {
        return pontos.slice(0);
    }

    var maior = 0.0;
    var indice = -1;
    var primeiro = pontos[0];
    var ultimo = pontos[pontos.length - 1];

    for (var i = 1; i < pontos.length - 1; i++) {
        var d = _distanciaPontoSegmentoM(pontos[i], primeiro, ultimo);
        if (d > maior) {
            maior = d;
            indice = i;
        }
    }

    if (indice >= 0 && maior > toleranciaM) {
        var esquerda = _rdp(pontos.slice(0, indice + 1), toleranciaM);
        var direita = _rdp(pontos.slice(indice), toleranciaM);
        return esquerda.slice(0, esquerda.length - 1).concat(direita);
    }

    return [primeiro, ultimo];
}

function simplificar(pontos, toleranciaM) {
    if (!pontos || pontos.length < 3 || !toleranciaM || toleranciaM <= 0) {
        return pontos ? pontos.slice(0) : [];
    }
    return _rdp(pontos, toleranciaM);
}

function _coord(p) {
    // Longitude primeiro: WKT em EPSG:4326 usado pelo QGIS/QField.
    return Number(p.lon).toFixed(9) + " " + Number(p.lat).toFixed(9);
}

function wktPonto(p) {
    return "POINT(" + _coord(p) + ")";
}

function wktLinha(pontos) {
    var c = [];
    for (var i = 0; i < pontos.length; i++) {
        c.push(_coord(pontos[i]));
    }
    return "LINESTRING(" + c.join(",") + ")";
}

function wktPoligono(pontos) {
    var c = [];
    for (var i = 0; i < pontos.length; i++) {
        c.push(_coord(pontos[i]));
    }
    c.push(_coord(pontos[0]));
    return "POLYGON((" + c.join(",") + "))";
}
