.pragma library

function localizarCamada(project, nome) {
    if (!project || !nome) {
        return { ok: false, mensagem: "Projeto ou nome de camada inválido." };
    }

    var encontradas = project.mapLayersByName(nome);
    if (!encontradas || encontradas.length === 0) {
        return {
            ok: false,
            mensagem: "A camada ‘" + nome + "’ não existe no projeto. Verifique o nome configurado no main.qml e o nome exibido na legenda."
        };
    }

    if (encontradas.length > 1) {
        return {
            ok: false,
            mensagem: "Há mais de uma camada chamada ‘" + nome + "’. Renomeie as camadas para tornar o nome único."
        };
    }

    return { ok: true, camada: encontradas[0] };
}

function resolverValorConfigurado(valor) {
    // Marcadores dinamicos sao resolvidos no instante do salvamento, e nao
    // quando o config.json e carregado. Isso garante um horario por feature.
    if (valor === "@now") {
        return new Date();
    }
    return valor;
}

function aplicarAtributos(feature, atributos) {
    var faltantes = [];
    if (!atributos) {
        return faltantes;
    }

    for (var nome in atributos) {
        var valor = resolverValorConfigurado(atributos[nome]);
        if (!feature.setAttribute(nome, valor)) {
            faltantes.push(nome);
        }
    }
    return faltantes;
}

function verificarCampos(feature, atributos, metadados) {
    var faltantes = [];
    var nome;

    // setAttribute() retorna false quando o campo nao existe. Como esta feature
    // e apenas temporaria, podemos usa-la para validar o esquema sem tocar na camada.
    if (atributos) {
        for (nome in atributos) {
            var valorAnterior = feature.attribute(nome);
            if (!feature.setAttribute(nome, valorAnterior)) {
                faltantes.push(nome);
            }
        }
    }

    if (metadados) {
        var campos = [
            metadados.latitudeCampo,
            metadados.longitudeCampo,
            metadados.precisaoCampo,
            metadados.fonteGpsCampo,
            metadados.dispositivoCampo
        ];
        for (var i = 0; i < campos.length; i++) {
            nome = campos[i];
            if (!nome) {
                continue;
            }
            var anterior = feature.attribute(nome);
            if (!feature.setAttribute(nome, anterior) && faltantes.indexOf(nome) < 0) {
                faltantes.push(nome);
            }
        }
    }

    return faltantes;
}

function aplicarMetadados(feature, metadados, info, deviceId) {
    var faltantes = [];
    if (!metadados || !info) {
        return faltantes;
    }

    function setSeConfigurado(campo, valor) {
        if (!campo) {
            return;
        }
        if (!feature.setAttribute(campo, valor)) {
            faltantes.push(campo);
        }
    }

    setSeConfigurado(metadados.latitudeCampo, info.latitude);
    setSeConfigurado(metadados.longitudeCampo, info.longitude);
    setSeConfigurado(metadados.precisaoCampo, info.haccValid ? info.hacc : null);
    setSeConfigurado(metadados.fonteGpsCampo, info.sourceName);
    setSeConfigurado(metadados.dispositivoCampo, deviceId || "");

    return faltantes;
}
