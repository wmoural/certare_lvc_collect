import QtQuick
import QtQuick.Controls
import org.qfield.core
import org.qfield.gui
import org.qgis

import "LayerService.js" as LayerService
import "GeometryService.js" as GeometryService

Item {
    id: plugin

    property var mainWindow: iface.mainWindow()
    property var positioning: iface.positioning()
    property var projectInfo: iface.findItemByObjectName("projectInfo")
    property var mapCanvas: iface.mapCanvas()

    // O plugin é global, mas sua interface deve existir somente durante uma
    // sessão de projeto/mapa. Na tela inicial do QField, projectOpen=false.
    property bool projectOpen: false
    readonly property bool mapVisible: mapCanvas !== null && mapCanvas !== undefined && mapCanvas.visible === true
    readonly property bool pluginUiVisible: projectOpen && mapVisible

    function updateProjectOpenState() {
        var opened = false;
        try {
            opened = qgisProject !== null
                     && qgisProject !== undefined
                     && qgisProject.fileName
                     && String(qgisProject.fileName()).trim().length > 0;
        } catch (e) {
            opened = false;
        }
        projectOpen = opened;
    }

    onProjectOpenChanged: {
        if (!projectOpen) {
            if (horizontalTracker && horizontalTracker.active) horizontalTracker.cancel();
            if (linearTracker && linearTracker.active) linearTracker.cancel();
            if (proximityController) proximityController.resetSession();
        } else {
            if (plugin.positioning && !plugin.positioning.active) plugin.positioning.active = true;
        }
    }

    // Interfaces nativas de formulário do QField. Quando uma feature existente
    // é aberta/selecionada para consulta ou edição, a interface rápida do
    // plugin é ocultada para não cobrir os widgets nativos.
    property var featureForm: iface.findItemByObjectName("featureForm")
    property var overlayFeatureFormDrawer: iface.findItemByObjectName("overlayFeatureFormDrawer")

    readonly property bool nativeFeatureFormOpen:
        ((featureForm !== null && featureForm !== undefined)
         && featureForm.visible === true
         && featureForm.state !== "Hidden")
        || ((overlayFeatureFormDrawer !== null && overlayFeatureFormDrawer !== undefined)
            && overlayFeatureFormDrawer.opened === true)

    function refreshNativeFormReferences() {
        if (!featureForm) {
            featureForm = iface.findItemByObjectName("featureForm");
        }
        if (!overlayFeatureFormDrawer) {
            overlayFeatureFormDrawer = iface.findItemByObjectName("overlayFeatureFormDrawer");
        }
    }

    property string pluginVersion: "1.10.4"

    // Linhas: amostragem exclusivamente temporal. O controlador lê o fix GNSS
    // corrente a cada 1 segundo; não há filtro por distância mínima ou máxima.
    property var gpsDefaults: ({
        intervaloMs: 1000,
        // Regra operacional: uma amostra temporal por segundo.
        // A precisão pode ser armazenada como metadado, mas não bloqueia a linha.
        precisaoMaximaM: 0.0,
        exigirPrecisaoValida: false,
        simplificacaoM: 0.0
    })

    property var metadataConfig: ({
        latitudeCampo: "",
        longitudeCampo: "",
        precisaoCampo: "",
        fonteGpsCampo: "",
        dispositivoCampo: ""
    })

    // -----------------------------------------------------------------
    // CONFIGURAÇÃO EXTERNA
    // Camadas, colunas, botões, grupos, imagens e valores gravados podem ser
    // alterados em config.json sem modificar este main.qml.
    // -----------------------------------------------------------------
    property var externalConfig: ({})
    property bool configLoaded: false
    property string configSource: "fallback interno"

    property var horizontalConditions: []
    property var horizontalBaseConfig: ({})
    property var linearButtons: []
    property var pointButtons: []
    property var proximityRuntimeConfig: ({ habilitado: false })

    function fallbackConfig() {
        return {
            versao_config: 6,
            camadas: {
                elementos_pontuais: {
                    nome: "Elementos",
                    colunas: { categoria: "CATEGORIA", elemento: "ELEMENTO", existe: "EXISTE?", data_coleta: "DATA COLETA" }
                },
                sinalizacao_horizontal: {
                    nome: "SinHorizontal",
                    colunas: { conservacao: "CONSERVAÇÃO" }
                },
                ciclovia: {
                    nome: "Inf. Cicloviária",
                    colunas: { tipo: "TIPO" }
                }
            },
            botoes: {
                pontuais: [
                    { nome: "Lombada", grupo: "Lombadas", cor: "#FF9800", imagem: "lombada.png", camada: "elementos_pontuais", valores: { categoria: "LOMBADA", elemento: "LOMBADA" } },
                    { nome: "Travessia elevada", grupo: "Lombadas", cor: "#FF9800", imagem: "travessia elevada.png", camada: "elementos_pontuais", valores: { categoria: "LOMBADA", elemento: "TRAVESSIA ELEVADA" } },
                    { nome: "Tachas transversais", grupo: "Lombadas", cor: "#FF9800", imagem: "tachas transversais.png", camada: "elementos_pontuais", valores: { categoria: "LOMBADA", elemento: "TACHAS TRANSVERSAIS" } },
                    { nome: "Pórtico", grupo: "Sinalização vertical", cor: "#2196F3", imagem: "portico.png", camada: "elementos_pontuais", valores: { categoria: "SINALIZAÇÃO VERTICAL", elemento: "PÓRTICO" } },
                    { nome: "Semi pórtico", grupo: "Sinalização vertical", cor: "#2196F3", imagem: "semiportico.png", camada: "elementos_pontuais", valores: { categoria: "SINALIZAÇÃO VERTICAL", elemento: "SEMI PÓRTICO" } },
                    { nome: "Braço cônico", grupo: "Sinalização vertical", cor: "#2196F3", imagem: "braco conico.png", camada: "elementos_pontuais", valores: { categoria: "SINALIZAÇÃO VERTICAL", elemento: "BRAÇO CÔNICO" } },
                    { nome: "Passarela", grupo: "Obras de arte", cor: "#9C27B0", imagem: "passarela.png", camada: "elementos_pontuais", valores: { categoria: "OBRA-DE-ARTE ESPECIAL", elemento: "PASSARELA" } },
                    { nome: "Viaduto", grupo: "Obras de arte", cor: "#9C27B0", imagem: "viaduto.png", camada: "elementos_pontuais", valores: { categoria: "OBRA-DE-ARTE ESPECIAL", elemento: "VIADUTO" } }
                ],
                lineares: [
                    { nome: "Ciclovia", grupo: "Estrutura cicloviária", cor: "#00ACC1", imagem: "ciclovia.png", camada: "ciclovia", valores: { tipo: "CICLOVIA" } }
                ],
                valores_padrao_pontuais: { data_coleta: "@now", existe: true },
                sinalizacao_horizontal: {
                    camada: "sinalizacao_horizontal",
                    campo_estado: "conservacao",
                    estados: [
                        { rotulo: "Bom", valor: "BOM", cor: "#43A047", imagem: "bom.png" },
                        { rotulo: "Regular", valor: "REGULAR", cor: "#F9A825", imagem: "regular.png" },
                        { rotulo: "Ruim", valor: "RUIM", cor: "#EF6C00", imagem: "ruim.png" },
                        { rotulo: "Inexistente", valor: "INEXISTENTE", cor: "#E53935", imagem: "inexistente.png" }
                    ]
                }
            },
            proximidade: {
                habilitado: true,
                camada: "elementos_pontuais",
                campo_confirmacao: "existe",
                campo_rotulo: "elemento",
                campo_secundario: "categoria",
                campo_filtro_nulo: "data_coleta",
                campo_data_atualizacao: "data_coleta",
                raio_metros: 15,
                intervalo_ms: 1000,
                valor_sim: true,
                valor_nao: false
            }
        };
    }

    function layerDefinition(aliasName) {
        if (!externalConfig || !externalConfig.camadas) return null;
        return externalConfig.camadas[aliasName] || null;
    }

    function attributesFromLogicalValues(layerDef, values) {
        var attrs = {};
        var cols = layerDef && layerDef.colunas ? layerDef.colunas : {};
        var vals = values || {};
        for (var logicalName in vals) {
            var realField = cols[logicalName];
            if (!realField) {
                throw new Error("A coluna lógica '" + logicalName + "' não está configurada para a camada.");
            }
            attrs[String(realField)] = vals[logicalName];
        }
        return attrs;
    }

    function buildButton(raw, geometryName) {
        var layerAlias = raw.camada;
        var layerDef = layerDefinition(layerAlias);
        if (!layerDef || !layerDef.nome) {
            throw new Error("Camada lógica '" + layerAlias + "' não encontrada em config.json.");
        }
        return {
            nome: String(raw.nome || "Sem nome"),
            grupo: String(raw.grupo || "Outros"),
            cor: String(raw.cor || "#607D8B"),
            imagem: raw.imagem ? String(raw.imagem) : "",
            camada: String(layerDef.nome),
            camadaLogica: String(layerAlias),
            geometria: geometryName,
            modo: geometryName === "Point" ? "gps_point" : "gps_track",
            atributos: attributesFromLogicalValues(layerDef, raw.valores || ({}))
        };
    }

    function rebuildCollectionConfig() {
        var btnCfg = externalConfig.botoes || {};
        var pointRaw = btnCfg.pontuais || [];
        var pointDefaults = btnCfg.valores_padrao_pontuais || ({});
        var linearRaw = btnCfg.lineares || [];
        var horizontalRaw = btnCfg.sinalizacao_horizontal || {};

        var newPoints = [];
        for (var i = 0; i < pointRaw.length; i++) {
            var rawPoint = pointRaw[i];
            var mergedPoint = {};
            for (var pk in rawPoint) mergedPoint[pk] = rawPoint[pk];
            var mergedValues = {};
            for (var dk in pointDefaults) mergedValues[dk] = pointDefaults[dk];
            var ownValues = rawPoint.valores || ({});
            for (var vk in ownValues) mergedValues[vk] = ownValues[vk];
            mergedPoint.valores = mergedValues;
            newPoints.push(buildButton(mergedPoint, "Point"));
        }
        pointButtons = newPoints;

        var newLines = [];
        for (var j = 0; j < linearRaw.length; j++) {
            newLines.push(buildButton(linearRaw[j], "LineString"));
        }
        linearButtons = newLines;

        var horizontalLayerAlias = horizontalRaw.camada || "sinalizacao_horizontal";
        var horizontalLayerDef = layerDefinition(horizontalLayerAlias);
        if (!horizontalLayerDef || !horizontalLayerDef.nome) {
            throw new Error("Camada lógica da sinalização horizontal não configurada.");
        }
        var logicalStateField = horizontalRaw.campo_estado || "conservacao";
        var realStateField = horizontalLayerDef.colunas ? horizontalLayerDef.colunas[logicalStateField] : "";
        if (!realStateField) {
            throw new Error("Coluna lógica '" + logicalStateField + "' da sinalização horizontal não configurada.");
        }
        horizontalBaseConfig = ({
            nome: "Sinalização horizontal",
            camada: String(horizontalLayerDef.nome),
            geometria: "LineString",
            modo: "gps_track",
            campoEstado: String(realStateField),
            atributos: ({})
        });

        var states = horizontalRaw.estados || [];
        var newStates = [];
        for (var k = 0; k < states.length; k++) {
            newStates.push({
                rotulo: String(states[k].rotulo || states[k].valor || "Estado"),
                valor: String(states[k].valor || ""),
                cor: String(states[k].cor || "#607D8B"),
                imagem: states[k].imagem ? String(states[k].imagem) : ""
            });
        }
        horizontalConditions = newStates;

        var proxRaw = externalConfig.proximidade || {};
        if (proxRaw.habilitado === true) {
            var proxAlias = proxRaw.camada || "elementos_pontuais";
            var proxLayerDef = layerDefinition(proxAlias);
            if (!proxLayerDef || !proxLayerDef.nome) {
                throw new Error("Camada lógica da proximidade não configurada: " + proxAlias);
            }
            var proxCols = proxLayerDef.colunas || {};
            var confirmationLogical = proxRaw.campo_confirmacao || "existe";
            var confirmationReal = proxCols[confirmationLogical];
            if (!confirmationReal) {
                throw new Error("Coluna lógica de confirmação não configurada: " + confirmationLogical);
            }
            var labelLogical = proxRaw.campo_rotulo || "elemento";
            var secondaryLogical = proxRaw.campo_secundario || "categoria";
            var nullFilterLogical = proxRaw.campo_filtro_nulo || "";
            var nullFilterReal = nullFilterLogical ? proxCols[nullFilterLogical] : "";
            if (nullFilterLogical && !nullFilterReal) {
                throw new Error("Coluna lógica do filtro NULL não configurada: " + nullFilterLogical);
            }
            var updateDateLogical = proxRaw.campo_data_atualizacao || "";
            var updateDateReal = updateDateLogical ? proxCols[updateDateLogical] : "";
            if (updateDateLogical && !updateDateReal) {
                throw new Error("Coluna lógica de data da proximidade não configurada: " + updateDateLogical);
            }
            proximityRuntimeConfig = ({
                habilitado: true,
                layerName: String(proxLayerDef.nome),
                confirmationField: String(confirmationReal),
                labelField: proxCols[labelLogical] ? String(proxCols[labelLogical]) : "",
                secondaryField: proxCols[secondaryLogical] ? String(proxCols[secondaryLogical]) : "",
                nullFilterField: nullFilterReal ? String(nullFilterReal) : "",
                updateDateField: updateDateReal ? String(updateDateReal) : "",
                raioMetros: Number(proxRaw.raio_metros || 15),
                intervaloMs: Number(proxRaw.intervalo_ms || 1000),
                valorSim: proxRaw.valor_sim === undefined ? true : proxRaw.valor_sim,
                valorNao: proxRaw.valor_nao === undefined ? false : proxRaw.valor_nao
            });
        } else {
            proximityRuntimeConfig = ({ habilitado: false });
        }
    }

    function applyExternalConfig(cfg) {
        if (!cfg || !cfg.camadas) {
            throw new Error("chave 'camadas' não encontrada");
        }
        externalConfig = cfg;
        rebuildCollectionConfig();
        configLoaded = true;
        configSource = "config.json";
    }

    function loadExternalConfig() {
        externalConfig = fallbackConfig();
        rebuildCollectionConfig();

        var xhr = new XMLHttpRequest();
        var url = Qt.resolvedUrl("config.json");
        xhr.onreadystatechange = function() {
            if (xhr.readyState !== XMLHttpRequest.DONE) return;

            if ((xhr.status === 200 || xhr.status === 0) && xhr.responseText && xhr.responseText.length > 0) {
                try {
                    applyExternalConfig(JSON.parse(xhr.responseText));
                } catch (e) {
                    externalConfig = fallbackConfig();
                    rebuildCollectionConfig();
                    configLoaded = false;
                    configSource = "fallback interno (config.json inválido)";
                    notify("Configuração inválida; usando padrão.", true);
                }
            } else {
                externalConfig = fallbackConfig();
                rebuildCollectionConfig();
                configLoaded = false;
                configSource = "fallback interno (config.json não encontrado)";
                notify("Configuração não encontrada; usando padrão.", true);
            }
        };
        xhr.open("GET", url, true);
        xhr.send();
    }

    function gpsForButton(buttonConfig) {
        var result = {};
        var key;
        var base = gpsDefaults;
        for (key in base) {
            result[key] = base[key];
        }
        if (buttonConfig && buttonConfig.gps) {
            for (key in buttonConfig.gps) {
                result[key] = buttonConfig.gps[key];
            }
        }
        return result;
    }

    function notify(text, isError) {
        if (text) {
            panel.showMessage(text, isError === true);
        }
    }

    function expectedGeometryType(name) {
        if (name === "Point") return Qgis.GeometryType.Point;
        if (name === "LineString") return Qgis.GeometryType.Line;
        if (name === "Polygon") return Qgis.GeometryType.Polygon;
        return Qgis.GeometryType.Unknown;
    }

    function validateConfigAndLayer(cfg) {
        if (!cfg || !cfg.nome || !cfg.camada || !cfg.geometria) {
            return { ok: false, mensagem: "Configuração interna de coleta incompleta no plugin." };
        }

        var result = LayerService.localizarCamada(qgisProject, cfg.camada);
        if (!result.ok) return result;

        var layer = result.camada;
        var expected = expectedGeometryType(cfg.geometria);
        if (expected === Qgis.GeometryType.Unknown) {
            return { ok: false, mensagem: "Geometria não suportada: " + cfg.geometria };
        }
        if (layer.geometryType() !== expected) {
            return { ok: false, mensagem: "A camada ‘" + cfg.camada + "’ não possui a geometria esperada (" + cfg.geometria + ")." };
        }
        if (QfLayerUtils.isFeatureAdditionLocked(layer)) {
            return { ok: false, mensagem: "A adição de features está bloqueada para a camada ‘" + cfg.camada + "’." };
        }

        var testFeature = QfFeatureUtils.createFeature(layer);
        var missing = LayerService.verificarCampos(testFeature, cfg.atributos || ({}), metadataConfig);
        if (missing.length > 0) {
            return { ok: false, mensagem: "Campo(s) inexistente(s) em ‘" + cfg.camada + "’: " + missing.join(", ") + "." };
        }
        return { ok: true, camada: layer };
    }

    function horizontalConfigForCondition(condition) {
        var cfg = {
            nome: "Sinalização horizontal — " + condition.rotulo,
            camada: horizontalBaseConfig.camada,
            geometria: horizontalBaseConfig.geometria,
            modo: horizontalBaseConfig.modo,
            atributos: ({}),
            conservacaoRotulo: condition.rotulo,
            conservacaoValor: condition.valor,
            cor: condition.cor || "#F9A825"
        };
        cfg.atributos[horizontalBaseConfig.campoEstado] = condition.valor;
        return cfg;
    }

    function selectHorizontalCondition(condition) {
        var cfg = horizontalConfigForCondition(condition);
        var validation = validateConfigAndLayer(cfg);
        if (!validation.ok) {
            notify(validation.mensagem, true);
            return;
        }

        if (horizontalTracker.active) {
            if (horizontalTracker.buttonConfig && horizontalTracker.buttonConfig.conservacaoValor === condition.valor) {
                return;
            }
            if (horizontalTracker.switchSegment(cfg)) {
                notify("Horizontal: " + condition.rotulo, false);
            }
            return;
        }

        if (!horizontalTracker.begin(validation.camada, cfg, gpsForButton(cfg))) {
            notify("Não foi possível iniciar a sinalização horizontal.", true);
            return;
        }
        notify("Horizontal: " + condition.rotulo, false);
    }

    function startLinearCollection(cfg) {
        var validation = validateConfigAndLayer(cfg);
        if (!validation.ok) {
            notify(validation.mensagem, true);
            return;
        }

        if (linearTracker.active) {
            if (linearTracker.buttonConfig && linearTracker.buttonConfig.nome === cfg.nome) {
                return;
            }
            if (linearTracker.switchSegment(cfg)) {
                panel.clearMessage();
            }
            return;
        }

        if (!linearTracker.begin(validation.camada, cfg, gpsForButton(cfg))) {
            notify("Não foi possível iniciar " + cfg.nome + ".", true);
            return;
        }
        notify(cfg.nome + " iniciada.", false);
    }

    function startPointCollection(cfg) {
        var validation = validateConfigAndLayer(cfg);
        if (!validation.ok) {
            notify(validation.mensagem, true);
            return;
        }

        // Pontos são instantâneos: usa-se o fix GNSS disponível exatamente no
        // momento do toque. Não existe fila nem estado "aguardando GNSS".
        if (plugin.positioning && !plugin.positioning.active) {
            plugin.positioning.active = true;
        }

        var info = plugin.positioning ? plugin.positioning.positionInformation : null;
        if (!info || !info.isValid || !info.latitudeValid || !info.longitudeValid) {
            var msg = "Sem posição GNSS válida no momento. Aguarde a localização e toque novamente em ‘" + cfg.nome + "’.";
            notify("GNSS indisponível. Tente novamente.", true);
            return;
        }

        var point = { lat: Number(info.latitude), lon: Number(info.longitude) };
        var sourceGeometry = QfGeometryUtils.createGeometryFromWkt(GeometryService.wktPonto(point));
        var geometry = QfGeometryUtils.reprojectGeometry(
            sourceGeometry,
            QfCoordinateReferenceSystemUtils.wgs84Crs(),
            validation.camada.crs
        );

        if (saveFeature(validation.camada, cfg, geometry, info, point)) {
            notify(cfg.nome + " salvo.", false);
        }
    }

    function createFeatureWithDefaults(layer, geometry, posInfo) {
        if (projectInfo) {
            return QfFeatureUtils.createFeature(layer, geometry, posInfo, projectInfo.cloudUserInformation);
        }
        return QfFeatureUtils.createFeature(layer, geometry, posInfo);
    }

    function saveFeature(layer, cfg, geometry, posInfo, acceptedPoint) {
        try {
            var feature = createFeatureWithDefaults(layer, geometry, posInfo);

            var missing = LayerService.aplicarAtributos(feature, cfg.atributos || ({}));
            if (missing.length > 0) {
                notify("Falha de esquema: " + missing.join(", "), true);
                return false;
            }

            missing = LayerService.aplicarMetadados(feature, metadataConfig, posInfo, positioning ? positioning.deviceId : "");
            if (missing.length > 0) {
                notify("Falha nos metadados: " + missing.join(", "), true);
                return false;
            }

            var startedHere = false;
            if (!layer.isEditable || !layer.isEditable()) {
                if (!layer.startEditing()) {
                    notify("Camada ‘" + cfg.camada + "’ não editável.", true);
                    return false;
                }
                startedHere = true;
            }

            if (!QfLayerUtils.addFeature(layer, feature)) {
                if (startedHere && layer.isEditable && layer.isEditable()) layer.rollBack();
                notify("Falha ao gravar em ‘" + cfg.camada + "’.", true);
                return false;
            }

            if (startedHere && !layer.commitChanges()) {
                var commitErrors = "";
                if (layer.commitErrors) {
                    var errs = layer.commitErrors();
                    if (errs && errs.length) commitErrors = " Detalhe: " + errs.join(" | ");
                }
                if (layer.isEditable && layer.isEditable()) layer.rollBack();
                notify("Falha ao salvar em ‘" + cfg.camada + "’." + commitErrors, true);
                return false;
            }

            // Força a atualização visual do mapa após salvar um segmento.
            if (layer.triggerRepaint) layer.triggerRepaint();
            var canvas = iface.mapCanvas();
            if (canvas && canvas.refresh) canvas.refresh(false);

            // Pontos recém-criados pelo próprio plugin não devem gerar a
            // pergunta de proximidade na mesma sessão. O FID salvo é
            // registrado imediatamente como já tratado pelo monitor.
            if (cfg.geometria === "Point"
                    && proximityController
                    && proximityRuntimeConfig
                    && proximityRuntimeConfig.layerName === cfg.camada) {
                proximityController.markFeatureHandled(feature);
            }

            return true;
        } catch (e) {
            notify("Erro ao salvar ‘" + cfg.nome + "’.", true);
            return false;
        }
    }

    GpsTrackController {
        id: horizontalTracker
        positioning: plugin.positioning
        saveHandler: function(layer, cfg, geometry, posInfo, acceptedPoint) {
            return plugin.saveFeature(layer, cfg, geometry, posInfo, acceptedPoint);
        }
        onErrorOccurred: function(message) {
            plugin.notify(message, true);
        }
        onSegmentSaved: function(label) {
            // Segmentos salvos sem notificação para não interromper a coleta.
        }
        onFeatureSaved: function(label) {
            plugin.notify("Sinalização horizontal salva.", false);
        }
    }

    GpsTrackController {
        id: linearTracker
        positioning: plugin.positioning
        saveHandler: function(layer, cfg, geometry, posInfo, acceptedPoint) {
            return plugin.saveFeature(layer, cfg, geometry, posInfo, acceptedPoint);
        }
        onErrorOccurred: function(message) {
            plugin.notify(message, true);
        }
        onSegmentSaved: function(label) {
            // Segmentos salvos sem notificação para não interromper a coleta.
        }
        onFeatureSaved: function(label) {
            plugin.notify(label + " salva.", false);
        }
    }

    // Prévia em tempo real dos dois rastreadores lineares.
    // O desenho é apenas visual; a feature continua sendo gravada somente
    // ao trocar de estado/tipo ou ao finalizar a coleta.
    TrackPreview {
        id: horizontalPreview
        mapCanvas: iface.mapCanvas()
        tracker: horizontalTracker
        appVisible: plugin.pluginUiVisible
        fallbackColor: "#F9A825"
    }

    TrackPreview {
        id: linearPreview
        mapCanvas: iface.mapCanvas()
        tracker: linearTracker
        appVisible: plugin.pluginUiVisible
        fallbackColor: "#00ACC1"
    }

    ProximityController {
        id: proximityController
        positioning: plugin.positioning
        project: qgisProject
        runtimeConfig: plugin.proximityRuntimeConfig
        suspended: plugin.nativeFeatureFormOpen || !plugin.pluginUiVisible
        notifyHandler: function(message, isError) {
            plugin.notify(message, isError);
        }
    }

    ProximityPrompt {
        id: proximityPrompt
        controller: proximityController
        projectActive: plugin.pluginUiVisible
    }

    QuickCollectionPanel {
        id: panel
        pointButtons: plugin.pointButtons
        linearButtons: plugin.linearButtons
        horizontalTracker: horizontalTracker
        linearTracker: linearTracker
        horizontalConditions: plugin.horizontalConditions
        suspendForNativeForm: plugin.nativeFeatureFormOpen
        suspendForProximityPrompt: proximityController.promptActive
        suspendForNoProject: !plugin.pluginUiVisible

        onPointRequested: function(config) {
            plugin.startPointCollection(config);
        }
        onLinearRequested: function(config) {
            plugin.startLinearCollection(config);
        }
        onHorizontalConditionRequested: function(condition) {
            plugin.selectHorizontalCondition(condition);
        }
        onHorizontalFinishRequested: function() {
            horizontalTracker.finish();
        }
        onLinearFinishRequested: function() {
            linearTracker.finish();
        }
    }

    Timer {
        id: nativeFormReferenceTimer
        interval: 1000
        repeat: true
        running: !plugin.featureForm || !plugin.overlayFeatureFormDrawer
        onTriggered: plugin.refreshNativeFormReferences()
    }

    Connections {
        target: qgisProject
        ignoreUnknownSignals: true

        function onFileNameChanged() { plugin.updateProjectOpenState(); }
        function onCleared() { plugin.updateProjectOpenState(); }
        function onReadProject() { Qt.callLater(plugin.updateProjectOpenState); }
    }

    Component.onCompleted: {
        refreshNativeFormReferences();
        updateProjectOpenState();
        loadExternalConfig();

        // Mantem o receptor de posicionamento aquecido para evitar cold start
        // quando o usuario toca em um elemento pontual.
        if (plugin.projectOpen && plugin.positioning && !plugin.positioning.active) {
            plugin.positioning.active = true;
        }
    }

    Component.onDestruction: {
        if (horizontalTracker.active) horizontalTracker.cancel();
        if (linearTracker.active) linearTracker.cancel();
        proximityController.resetSession();
    }
}
