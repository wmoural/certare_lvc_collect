# Coleta Rápida Viária — v1.10.4

Plugin QField para coleta rápida de elementos viários.

## Ajustes v1.10.4

- Elementos pontuais são gravados **imediatamente no toque**, usando o fix GNSS válido já disponível. Não existe mais uma coleta pendente em “aguardando GNSS”. Se não houver latitude/longitude válidas naquele instante, o plugin apenas informa o usuário e exige um novo toque.
- Coletas lineares usam **amostragem exclusivamente temporal**, com leitura do fix GNSS a cada **1 segundo** (`intervaloMs: 1000`). Não há filtro por distância mínima ou distância máxima entre vértices.
- O filtro de precisão GNSS continua aplicado às linhas. Portanto, a cada segundo o plugin tenta registrar um vértice; uma amostra pode ser ignorada se o fix estiver inválido ou fora do limite de precisão configurado.
- Troca de estado da sinalização horizontal, troca entre Ciclovia e encerramento capturam também um ponto de transição/final para evitar lacunas entre segmentos.

- No **modo retrato**, os quatro estados da sinalização horizontal voltam ao arranjo original em **coluna vertical**.
- No **modo paisagem**, os quatro estados permanecem em **grid 2x2**.
- Os arquivos PNG fornecidos em `Nova pasta.zip` agora são distribuídos junto do plugin e usados diretamente pelos botões correspondentes.


## Estrutura mínima

```text
qfield_coleta_rapida/
├── main.qml
├── QuickCollectionPanel.qml
├── GpsTrackController.qml
├── GeometryService.js
├── LayerService.js
├── metadata.txt
└── icon.svg
```

## Camadas esperadas

### Elementos
Geometria `Point`, com os campos `CATEGORIA` e `ELEMENTO`.

### SinHorizonta
Geometria `LineString`, com o campo `CONSERVAÇÃO`.

Valores gravados: `BOM`, `REGULAR`, `RUIM`, `INEXISTENTE`.

### Track
Geometria `LineString`, com os campos `CATEGORIA` e `ELEMENTO`.

Usada para:
- Ciclovia

## Comportamento

A sinalização horizontal permanece em rastreamento enquanto o usuário alterna o estado de conservação. Cada alteração salva o trecho anterior e começa o próximo no mesmo limite.

Ciclovia possuem rastreador linear separado. Assim, podem ser coletadas sem interromper a sinalização horizontal. Elementos pontuais também podem ser registrados enquanto os rastreadores lineares estão ativos.

## Interface

Os elementos lineares ficam à esquerda e os pontuais à direita. Os grupos ficam separados, sem painel de fundo opaco e acima da faixa ocupada pelos controles nativos do QField. A interface não exibe precisão ou contagem de vértices.

## Instalação manual

Descompacte o plugin dentro de:

```text
/storage/emulated/0/Android/data/ch.opengis.qfield/files/QField/plugins/qfield_coleta_rapida/
```

O `main.qml` deve ficar diretamente dentro da pasta do plugin.


## Ajustes v1.7.0

- GNSS pre-aquecido no carregamento do plugin para reduzir o atraso em pontos.
- Pontos usam limite de precisao de 15 m; tracking linear permanece com 8 m.
- A mensagem de espera so aparece se o fix atual ainda nao estiver apto.
- Layout redesenhado: lineares justificados a esquerda e pontuais a direita, com margem de seguranca para controles nativos do QField.
- Botoes menores, translúcidos e com marcadores coloridos por grupo/estado.
- Sem paineis opacos gerais.

Observacao: manter o GNSS ativo reduz o cold start, mas pode aumentar o consumo de bateria durante a sessao de campo.


## Ajuste v1.8.8 — notificações transitórias

As notificações do plugin usam um único toast transitório próprio, com duração aproximada de 1,25 s e reposicionamento conforme a orientação da tela. O sistema nativo de toast do QField não é alterado nem desativado. Isso evita duplicação de mensagens e permite controlar posição/duração sem interferir nas notificações do aplicativo.

## Configuracao externa (config.json)

A partir da v1.8.8, os nomes das camadas e das colunas principais podem ser alterados sem editar o `main.qml`. Edite apenas o arquivo `config.json`, mantendo-o na mesma pasta do plugin.

Configuracao atual:

```json
{
  "versao_config": 1,
  "camadas": {
    "elementos_pontuais": {
      "nome": "Elementos",
      "colunas": {
        "categoria": "CATEGORIA",
        "elemento": "ELEMENTO"
      }
    },
    "sinalizacao_horizontal": {
      "nome": "SinHorizonta",
      "colunas": {
        "conservacao": "CONSERVAÇÃO"
      }
    },
    "ciclovia": {
      "nome": "Track",
      "colunas": {
        "categoria": "CATEGORIA",
        "elemento": "ELEMENTO"
      }
    }
  }
}
```

Exemplo: se a camada `Elementos` passar a se chamar `Elementos_Viarios` e o campo `CATEGORIA` passar a se chamar `TIPO`, altere somente:

```json
"elementos_pontuais": {
  "nome": "Elementos_Viarios",
  "colunas": {
    "categoria": "TIPO",
    "elemento": "ELEMENTO"
  }
}
```

Reinicie o QField apos alterar o arquivo. Se o JSON estiver ausente ou invalido, o plugin usa a configuracao padrao embutida e exibe um aviso temporario.


## v1.10.4 - Formulários nativos

Quando o formulário nativo de uma feature estiver aberto no QField, os botões do plugin são ocultados automaticamente para evitar sobreposição. Ao fechar o formulário, os controles reaparecem. Coletas lineares ativas continuam em segundo plano.


## Configuração v2: botões pelo `config.json`

A partir da v1.10.4, os botões também podem ser criados e alterados pelo `config.json`, sem editar o `main.qml`. Cada item de `botoes.pontuais` ou `botoes.lineares` informa `nome`, `grupo`, `cor`, `imagem`, a chave lógica da `camada` e os `valores` a gravar. As chaves dentro de `valores` correspondem às chaves lógicas declaradas em `camadas.<chave>.colunas`.

Exemplo de novo ponto na camada `Elementos`:

```json
{
  "nome": "Novo elemento",
  "grupo": "Novo grupo",
  "cor": "#607D8B",
  "imagem": "novo elemento.png",
  "camada": "elementos_pontuais",
  "valores": {
    "categoria": "NOVA CATEGORIA",
    "elemento": "NOVO ELEMENTO"
  }
}
```

O arquivo de imagem, se usado, deve estar na mesma pasta do plugin. Reinicie o QField após alterar o `config.json`.


## v1.10.4 - rastreamento linear

- Prévia visual da linha em tempo real sobre o mapa.
- Amostragem temporal a cada 1 segundo.
- Por padrão, precisão horizontal não bloqueia amostras lineares; latitude/longitude válidas são suficientes.
- O mapa é atualizado após cada segmento salvo.

## Monitoramento automático de proximidade (v1.10.4)

A versão 1.10.4 adiciona uma verificação automática dos pontos existentes da camada configurada em `proximidade`. Enquanto o GNSS estiver ativo, o plugin consulta apenas as features dentro do raio definido em `raio_metros` e, ao encontrar o ponto mais próximo ainda não confirmado na sessão, apresenta a pergunta **"Este elemento ainda existe?"**.

As respostas **SIM** e **NÃO** atualizam diretamente o campo configurado em `campo_confirmacao`. A opção **DEPOIS** fecha a pergunta sem alterar a feature e só permite que o mesmo ponto seja perguntado novamente depois que o usuário sair do raio e entrar novamente. As confirmações SIM/NÃO não são repetidas durante a mesma sessão do plugin.

Configuração atual:

```json
"proximidade": {
  "habilitado": true,
  "camada": "elementos_pontuais",
  "campo_confirmacao": "existe",
  "campo_rotulo": "elemento",
  "campo_secundario": "categoria",
  "raio_metros": 15,
  "intervalo_ms": 1000,
  "valor_sim": true,
  "valor_nao": false
}
```

A chave lógica `existe` é mapeada na camada `Elementos` para o campo físico `EXISTE?`:

```json
"elementos_pontuais": {
  "nome": "Elementos",
  "colunas": {
    "categoria": "CATEGORIA",
    "elemento": "ELEMENTO",
    "existe": "EXISTE?"
  }
}
```

O monitoramento não interrompe a coleta linear de sinalização horizontal ou ciclovia. Quando a pergunta é exibida, apenas os botões de coleta rápida são ocultados temporariamente para evitar toques acidentais.


## v1.10.4 — pontos recém-criados
Pontos criados pelo próprio plugin na camada monitorada por proximidade são marcados como tratados na sessão imediatamente após a gravação. Assim, eles não disparam a pergunta “Este elemento ainda existe?” durante a mesma sessão do QField. Pontos previamente existentes continuam sendo verificados normalmente.


## v1.10.4 - valores automaticos dos pontos

O bloco `botoes.valores_padrao_pontuais` do `config.json` e aplicado a todos os botoes pontuais. A configuracao atual grava `DATA COLETA` com `@now` (data/hora no instante do salvamento) e `EXISTE?` como `true`.


## Filtro de proximidade por DATA COLETA (v1.10.4)
A checagem automática de existência considera somente pontos dentro do raio configurado cujo campo `DATA COLETA` esteja NULL. O campo é indicado no `config.json` por `proximidade.campo_filtro_nulo = "data_coleta"`. Pontos novos criados pelo plugin recebem data/hora e, portanto, ficam automaticamente fora da checagem.


## v1.10.4
- A confirmação SIM/NÃO de proximidade atualiza também a coluna DATA COLETA com a data/hora atual.
- Os controles do plugin ficam ocultos quando não há projeto aberto no QField e reaparecem ao entrar no mapa de um projeto.
