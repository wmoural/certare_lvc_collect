# Projeto atual - Coleta Rapida Viaria v1.10.4

A configuracao de nomes de camadas e colunas foi externalizada para `config.json`.

Configuracao atual:

- Pontuais: camada `Elementos`; campos `CATEGORIA` e `ELEMENTO`.
- Sinalizacao horizontal: camada `SinHorizonta`; campo `CONSERVAÇÃO`.
- Ciclovia: camada `Track`; campos `CATEGORIA` e `ELEMENTO`.

Os valores de classificacao continuam definidos pelo plugin: sinalizacao horizontal (`BOM`, `REGULAR`, `RUIM`, `INEXISTENTE`), Ciclovia (`ESTRUTURA CICLOVIÁRIA` / `CICLOVIA`) e os elementos pontuais ja cadastrados.

Depois de editar `config.json`, reinicie o QField para recarregar a configuracao.


## v1.10.4 - Formulários nativos

Quando o formulário nativo de uma feature estiver aberto no QField, os botões do plugin são ocultados automaticamente para evitar sobreposição. Ao fechar o formulário, os controles reaparecem. Coletas lineares ativas continuam em segundo plano.

## v1.10.4 — Confirmação por proximidade
- A camada `Elementos` passa a usar também o campo `EXISTE?` no `config.json`.
- O plugin procura pontos a até 15 m da posição GNSS a cada 1 s.
- Ao encontrar o ponto mais próximo ainda não confirmado, pergunta se o elemento ainda existe.
- SIM grava `true`; NÃO grava `false`; DEPOIS não altera o registro e rearma após sair do raio.
- O tracking de linhas continua ativo em segundo plano durante a pergunta.


## v1.10.4 — pontos recém-criados
Pontos criados pelo próprio plugin na camada monitorada por proximidade são marcados como tratados na sessão imediatamente após a gravação. Assim, eles não disparam a pergunta “Este elemento ainda existe?” durante a mesma sessão do QField. Pontos previamente existentes continuam sendo verificados normalmente.


## v1.10.4 - valores automaticos dos pontos

O bloco `botoes.valores_padrao_pontuais` do `config.json` e aplicado a todos os botoes pontuais. A configuracao atual grava `DATA COLETA` com `@now` (data/hora no instante do salvamento) e `EXISTE?` como `true`.


## Filtro de proximidade por DATA COLETA (v1.10.4)
A checagem automática de existência considera somente pontos dentro do raio configurado cujo campo `DATA COLETA` esteja NULL. O campo é indicado no `config.json` por `proximidade.campo_filtro_nulo = "data_coleta"`. Pontos novos criados pelo plugin recebem data/hora e, portanto, ficam automaticamente fora da checagem.


## v1.10.4
- A confirmação SIM/NÃO de proximidade atualiza também a coluna DATA COLETA com a data/hora atual.
- Os controles do plugin ficam ocultos quando não há projeto aberto no QField e reaparecem ao entrar no mapa de um projeto.
