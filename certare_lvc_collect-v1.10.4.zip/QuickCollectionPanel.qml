import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qfield.core
import org.qfield.gui

Item {
    id: panel

    property var pointButtons: []
    property var linearButtons: []
    property var horizontalTracker: null
    property var linearTracker: null
    property var pointTracker: null
    property var horizontalConditions: []
    property string message: ""
    property bool messageIsError: false
    // Oculta todo o dock do plugin enquanto um formulário nativo de feature
    // estiver aberto. A lógica/tracking continua ativa no main.qml.
    property bool suspendForNativeForm: false
    property bool suspendForProximityPrompt: false
    property bool suspendForNoProject: false

    // =====================================================================
    // Orientação: "auto" segue a tela; "portrait" / "landscape" forçam um modo
    // =====================================================================
    property string layoutMode: "auto"
    readonly property bool isLandscape: layoutMode === "landscape"
                                        || (layoutMode === "auto" && width > height)

    // Tamanho dos botões em cada orientação (o resto é proporcional)
    property int buttonSizePortrait: 65
    property int buttonSizeLandscape: 78
    readonly property int buttonSize: isLandscape ? buttonSizeLandscape : buttonSizePortrait
    readonly property int buttonFontSize: Math.round(buttonSize * 0.26)
    readonly property int dockSpacing: Math.round(buttonSize * 0.18)
    property int stopGap: 10

    // Losango (paisagem)
    // diamondSpread: distância do centro aos botões, em múltiplos do tamanho do botão.
    // 0.8 = botões quase encostados; aumente para afastá-los.
    property real diamondSpread: 0.8
    readonly property int stopSize: buttonSize                        // botão "encerrar" (PARAR)
    readonly property int clusterGap: Math.round(buttonSize * 0.22)   // usado apenas no retrato/compatibilidade

    // Paisagem: composição compacta para manter todos os botões visíveis.
    // As categorias pontuais ficam em linhas empilhadas à direita, com leve
    // deslocamento horizontal entre elas para criar uma inclinação discreta.
    readonly property int landscapeButtonGap: 4
    readonly property int landscapeGroupGap: 2
    readonly property int landscapeGroupTilt: 12

    // Margens de segurança (barras nativas do QField)
    readonly property int safeBottomMargin: isLandscape ? 72 : 112
    readonly property int safeTopMargin: isLandscape ? 64 : 84
    readonly property int safeLeftMargin: isLandscape ? 12 : 8
    readonly property int safeRightMargin: isLandscape ? 12 : 8

    // Ícones (PNG branco com transparência, na mesma pasta deste arquivo)
    readonly property url iconHorizontal: Qt.resolvedUrl("sinalizacaohorizontal.png")
    readonly property url iconCycle: Qt.resolvedUrl("ciclo.png")
    readonly property url iconLombada: Qt.resolvedUrl("lombada.png")
    readonly property url iconVertical: Qt.resolvedUrl("vertical.png")
    readonly property url iconOeas: Qt.resolvedUrl("oeas.png")
    property real iconOpacity: 0.42

    // Botões que são a própria imagem (PNG com o texto já incluído, mesma pasta)
    readonly property url imgBom: Qt.resolvedUrl("bom.png")
    readonly property url imgRegular: Qt.resolvedUrl("regular.png")
    readonly property url imgRuim: Qt.resolvedUrl("ruim.png")
    readonly property url imgInexistente: Qt.resolvedUrl("inexistente.png")
    readonly property url imgParar: Qt.resolvedUrl("parar.png")
    readonly property url imgCiclovia: Qt.resolvedUrl("ciclovia.png")

    // Imagens dos elementos pontuais (arquivos na mesma pasta do plugin)
    readonly property url imgBracoConico: Qt.resolvedUrl("braco conico.png")
    readonly property url imgLombada: Qt.resolvedUrl("lombada.png")
    readonly property url imgPassarela: Qt.resolvedUrl("passarela.png")
    readonly property url imgPortico: Qt.resolvedUrl("portico.png")
    readonly property url imgSemiportico: Qt.resolvedUrl("semiportico.png")
    readonly property url imgTachasTransversais: Qt.resolvedUrl("tachas transversais.png")
    readonly property url imgTravessiaElevada: Qt.resolvedUrl("travessia elevada.png")
    readonly property url imgViaduto: Qt.resolvedUrl("viaduto.png")

    // Etiqueta com o nome completo (aparece enquanto o botão está pressionado)
    property string hintText: ""
    property real hintAnchorX: 0
    property real hintTopY: 0
    property real hintCenterY: 0
    property real hintW: 0
    property bool hintOnLeft: false

    signal pointRequested(var config)
    signal linearRequested(var config)
    signal horizontalConditionRequested(var condition)
    signal horizontalFinishRequested()
    signal linearFinishRequested()

    parent: iface.mainWindow().contentItem
    anchors.fill: parent
    visible: !panel.suspendForNoProject && !panel.suspendForNativeForm && !panel.suspendForProximityPrompt
    enabled: visible
    z: 7000

    function showMessage(text, isError) {
        message = text || "";
        messageIsError = isError === true;
        toastTimer.restart();
    }

    function clearMessage() {
        toastTimer.stop();
        message = "";
        messageIsError = false;
    }

    function showHint(item, text, onLeft) {
        var p = item.mapToItem(panel, 0, 0);
        hintAnchorX = p.x;
        hintTopY = p.y;
        hintCenterY = p.y + item.height / 2;
        hintW = item.width;
        hintOnLeft = onLeft;
        hintText = text;
    }

    function hideHint() {
        hintText = "";
    }

    function abbreviate(name) {
        var words = (name || "").trim().split(/\s+/);
        var big = [];
        for (var i = 0; i < words.length; i++) {
            if (words[i].length > 2) big.push(words[i]);
        }
        if (big.length === 0) big = words;
        if (big.length >= 2) return (big[0].charAt(0) + big[1].charAt(0)).toUpperCase();
        return (big[0] || "").substring(0, 3).toUpperCase();
    }

    function textOn(c) {
        var lum = 0.299 * c.r + 0.587 * c.g + 0.114 * c.b;
        return lum > 0.72 ? "#1A1A1A" : "white";
    }

    function buttonsByGroup(groupName) {
        var out = [];
        for (var i = 0; i < pointButtons.length; i++) {
            var b = pointButtons[i];
            if (b && b.grupo === groupName) out.push(b);
        }
        return out;
    }

    function pointGroups() {
        // Os grupos agora são derivados do config.json. A ordem é a ordem da
        // primeira ocorrência de cada grupo em botoes.pontuais.
        var groups = [];
        var indexByName = {};
        for (var i = 0; i < pointButtons.length; i++) {
            var b = pointButtons[i];
            if (!b) continue;
            var groupName = b.grupo || "Outros";
            if (indexByName[groupName] === undefined) {
                indexByName[groupName] = groups.length;
                groups.push({
                    nome: groupName,
                    cor: b.cor || "#607D8B",
                    icone: "",
                    botoes: []
                });
            }
            groups[indexByName[groupName]].botoes.push(b);
        }
        return groups;
    }

    function currentConditionValue() {
        if (!horizontalTracker || !horizontalTracker.active || !horizontalTracker.buttonConfig) return "";
        return horizontalTracker.buttonConfig.conservacaoValor || "";
    }

    function currentConditionLabel() {
        var v = currentConditionValue();
        if (v === "") return "";
        for (var i = 0; i < horizontalConditions.length; i++) {
            if (horizontalConditions[i].valor === v) return horizontalConditions[i].rotulo;
        }
        return v;
    }

    function currentLinearName() {
        if (!linearTracker || !linearTracker.active || !linearTracker.buttonConfig) return "";
        return linearTracker.buttonConfig.nome || "";
    }

    function resolvedImage(fileName) {
        if (!fileName) return "";
        return Qt.resolvedUrl(String(fileName));
    }

    function conditionImage(value) {
        for (var i = 0; i < horizontalConditions.length; i++) {
            var c = horizontalConditions[i];
            if (c && c.valor === value && c.imagem) return resolvedImage(c.imagem);
        }
        // Compatibilidade com configurações antigas.
        if (value === "BOM") return imgBom;
        if (value === "REGULAR") return imgRegular;
        if (value === "RUIM") return imgRuim;
        if (value === "INEXISTENTE") return imgInexistente;
        return "";
    }

    function pointImage(config) {
        if (config && config.imagem) return resolvedImage(config.imagem);
        var name = config ? config.nome : "";
        // Compatibilidade com configurações antigas.
        if (name === "Lombada") return imgLombada;
        if (name === "Travessia elevada") return imgTravessiaElevada;
        if (name === "Tachas transversais") return imgTachasTransversais;
        if (name === "Pórtico") return imgPortico;
        if (name === "Semi pórtico") return imgSemiportico;
        if (name === "Braço cônico") return imgBracoConico;
        if (name === "Passarela") return imgPassarela;
        if (name === "Viaduto") return imgViaduto;
        return "";
    }

    function linearImage(config) {
        if (config && config.imagem) return resolvedImage(config.imagem);
        if (config && config.nome === "Ciclovia") return imgCiclovia;
        return "";
    }

    function conditionColor(value) {
        for (var i = 0; i < horizontalConditions.length; i++) {
            var c = horizontalConditions[i];
            if (c && c.valor === value && c.cor) return c.cor;
        }
        if (value === "BOM") return "#43A047";
        if (value === "REGULAR") return "#F9A825";
        if (value === "RUIM") return "#EF6C00";
        if (value === "INEXISTENTE") return "#E53935";
        return "#607D8B";
    }

    // =====================================================================
    // Losangos (paisagem)
    // Cada losango tem até 4 botões, no sentido horário a partir do topo:
    // topo, direita, baixo, esquerda. Grupos com mais de 4 itens viram
    // vários losangos lado a lado. Retorna as posições já calculadas.
    // =====================================================================
    function diamondClusters(items, includeCenter) {
        var s = buttonSize;
        var d = Math.round(s * diamondSpread);
        var st = stopSize;
        var order = [[0, -1], [1, 0], [0, 1], [-1, 0]];
        var out = [];
        var list = items || [];
        for (var start = 0; start < list.length; start += 4) {
            var chunk = list.slice(start, start + 4);
            var minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9;
            var pts = [];
            for (var i = 0; i < chunk.length; i++) {
                var px = order[i][0] * d;
                var py = order[i][1] * d;
                pts.push({ cfg: chunk[i], cx: px, cy: py });
                minX = Math.min(minX, px - s / 2);
                maxX = Math.max(maxX, px + s / 2);
                minY = Math.min(minY, py - s / 2);
                maxY = Math.max(maxY, py + s / 2);
            }
            var hasStop = includeCenter && start === 0;
            var e = 0;
            if (hasStop) {
                // posição diagonal (canto superior esquerdo) sem encostar nos vizinhos
                var D = s / 2 + st / 2 + 4;
                e = Math.ceil((d + Math.sqrt(Math.max(0, 2 * D * D - d * d))) / 2);
                minX = Math.min(minX, -e - st / 2);
                maxX = Math.max(maxX, -e + st / 2);
                minY = Math.min(minY, -e - st / 2);
                maxY = Math.max(maxY, -e + st / 2);
            }
            var btns = [];
            for (var k = 0; k < pts.length; k++) {
                btns.push({ cfg: pts[k].cfg, x: pts[k].cx - s / 2 - minX, y: pts[k].cy - s / 2 - minY });
            }
            out.push({
                w: Math.ceil(maxX - minX),
                h: Math.ceil(maxY - minY),
                buttons: btns,
                hasStop: hasStop,
                stopX: -e - st / 2 - minX,
                stopY: -e - st / 2 - minY
            });
        }
        return out;
    }

    function tagClusters(list, kind, cor, icone) {
        for (var i = 0; i < list.length; i++) {
            list[i].kind = kind;
            list[i].cor = cor;
            list[i].icone = icone;
        }
        return list;
    }

    function leftClusters() {
        var out = [];
        var c = tagClusters(diamondClusters(horizontalConditions, true), "cond", "", iconHorizontal);
        for (var i = 0; i < c.length; i++) out.push(c[i]);
        var l = tagClusters(diamondClusters(linearButtons, true), "cycle", "#00ACC1", iconCycle);
        for (var j = 0; j < l.length; j++) out.push(l[j]);
        return out;
    }

    function rightClusters() {
        var out = [];
        var groups = pointGroups();
        for (var g = 0; g < groups.length; g++) {
            var c = tagClusters(diamondClusters(groups[g].botoes, false), "point", groups[g].cor, groups[g].icone);
            for (var i = 0; i < c.length; i++) out.push(c[i]);
        }
        return out;
    }

    // =====================================================================
    // Componente: botão redondo estilo SNES (encaixe escuro + tecla convexa)
    // =====================================================================
    component DockButton: Button {
        id: btn
        property color accent: "#00ACC1"
        property bool active: false
        property bool dimmed: false
        property bool rightAligned: false
        property bool isStop: false
        property url iconSource: ""
        property url imageSource: ""          // se definido: a imagem É o botão (sem fundo, sem texto)
        readonly property bool hasImage: imageSource.toString() !== ""
        property string label: ""
        property string shortLabel: panel.abbreviate(label)
        property int sizePx: panel.buttonSize
        readonly property int inset: Math.max(3, Math.round(sizePx * 0.075))
        readonly property int pressDrop: btn.down ? Math.max(2, Math.round(sizePx * 0.04)) : 0

        implicitWidth: sizePx
        implicitHeight: sizePx
        flat: true
        padding: 0

        onDownChanged: {
            if (down) panel.showHint(btn, label, rightAligned);
            else panel.hideHint();
        }
        onVisibleChanged: if (!visible) panel.hideHint()

        background: Item {
            opacity: !btn.enabled ? 0.4 : (btn.dimmed ? 0.55 : 1.0)

            // ---- Botão feito só de imagem ----
            Image {
                anchors.fill: parent
                visible: btn.hasImage
                source: btn.imageSource
                sourceSize.width: 256
                sourceSize.height: 256
                fillMode: Image.PreserveAspectFit
                smooth: true
                mipmap: true
                scale: btn.down ? 0.93 : 1.0
                opacity: btn.down ? 0.85 : 1.0
                Behavior on scale { NumberAnimation { duration: 70 } }
            }

            // Anel de seleção (só para botões-imagem)
            Rectangle {
                anchors.fill: parent
                visible: btn.hasImage && btn.active
                radius: width / 2
                color: "transparent"
                border.width: 3
                border.color: "white"
            }

            // Encaixe (corpo do controle)
            Rectangle {
                visible: !btn.hasImage
                anchors.fill: parent
                radius: width / 2
                color: "#14151C"
                border.width: btn.active ? 3 : 1
                border.color: btn.active ? "white" : "#55FFFFFF"
            }

            // Tecla convexa
            Rectangle {
                id: key
                visible: !btn.hasImage
                x: btn.inset
                y: btn.inset + btn.pressDrop
                width: parent.width - 2 * btn.inset
                height: width
                radius: width / 2
                border.width: 1
                border.color: Qt.darker(btn.accent, 1.9)
                gradient: Gradient {
                    GradientStop { position: 0.0; color: btn.down ? Qt.darker(btn.accent, 1.05) : Qt.lighter(btn.accent, 1.5) }
                    GradientStop { position: 0.5; color: btn.down ? Qt.darker(btn.accent, 1.25) : btn.accent }
                    GradientStop { position: 1.0; color: Qt.darker(btn.accent, btn.down ? 1.8 : 1.55) }
                }

                Image {
                    anchors.fill: parent
                    anchors.margins: Math.round(key.width * 0.14)
                    visible: !btn.isStop && btn.iconSource.toString() !== ""
                    source: btn.iconSource
                    sourceSize.width: 128
                    sourceSize.height: 128
                    fillMode: Image.PreserveAspectFit
                    smooth: true
                    mipmap: true
                    opacity: panel.iconOpacity
                }

                // Brilho
                Rectangle {
                    anchors.horizontalCenter: parent.horizontalCenter
                    y: Math.round(parent.height * 0.07)
                    width: Math.round(parent.width * 0.62)
                    height: Math.round(parent.height * 0.3)
                    radius: height / 2
                    opacity: btn.down ? 0.45 : 1.0
                    gradient: Gradient {
                        GradientStop { position: 0.0; color: "#99FFFFFF" }
                        GradientStop { position: 1.0; color: "#00FFFFFF" }
                    }
                }
            }
        }

        contentItem: Item {
            opacity: btn.enabled ? 1.0 : 0.6

            Label {
                anchors.centerIn: parent
                anchors.verticalCenterOffset: btn.pressDrop
                visible: !btn.isStop && !btn.hasImage
                text: btn.shortLabel
                color: panel.textOn(btn.accent)
                font.pixelSize: panel.buttonFontSize
                font.bold: true
                style: Text.Outline
                styleColor: panel.textOn(btn.accent) === "white" ? "#66000000" : "#66FFFFFF"
            }

            Rectangle {
                anchors.centerIn: parent
                anchors.verticalCenterOffset: btn.pressDrop
                visible: btn.isStop && !btn.hasImage
                width: Math.round(btn.sizePx * 0.32); height: width; radius: 3
                color: "white"
            }
        }
    }

    // Traço fino separando famílias de cor (só no modo retrato)
    component Divider: Rectangle {
        width: panel.buttonSize * 0.5
        height: 2
        radius: 1
        color: "#66FFFFFF"
        x: (panel.buttonSize - width) / 2
    }

    // =====================================================================
    // Toast transitório do plugin
    // - uma única mensagem por vez;
    // - curta duração;
    // - retrato: região central superior;
    // - paisagem: bem próximo ao topo.
    // O sistema nativo de toast do QField permanece intocado.
    // =====================================================================
    Timer {
        id: toastTimer
        interval: 1250
        repeat: false
        onTriggered: {
            panel.message = "";
            panel.messageIsError = false;
        }
    }

    Rectangle {
        id: messageBox
        anchors.top: parent.top
        anchors.topMargin: panel.isLandscape ? 8 : panel.safeTopMargin
        anchors.horizontalCenter: parent.horizontalCenter
        width: Math.min(messageLabel.implicitWidth + 28, parent.width * (panel.isLandscape ? 0.50 : 0.68))
        height: 34
        visible: panel.message.length > 0
        radius: 17
        color: panel.messageIsError ? "#DCB71C1C" : "#D0101A33"
        border.color: panel.messageIsError ? "#FFFFCDD2" : "#66FFFFFF"
        border.width: 1
        z: 7030

        Label {
            id: messageLabel
            anchors.fill: parent
            anchors.leftMargin: 14
            anchors.rightMargin: 14
            text: panel.message
            color: "white"
            font.pixelSize: 12
            font.bold: true
            elide: Text.ElideRight
            verticalAlignment: Text.AlignVCenter
            horizontalAlignment: Text.AlignHCenter
        }
    }

    // =====================================================================
    // Chips de status (o que está ativo agora)
    // =====================================================================
    Column {
        id: statusChips
        anchors.top: parent.top
        anchors.topMargin: panel.safeTopMargin + (messageBox.visible ? messageBox.height + 8 : 0)
        anchors.horizontalCenter: parent.horizontalCenter
        spacing: 6
        z: 7005

        Rectangle {
            visible: panel.currentConditionLabel() !== ""
            height: 30
            width: hChipLabel.implicitWidth + 32
            radius: 15
            color: "#D0101A33"
            border.width: 2
            border.color: panel.conditionColor(panel.currentConditionValue())
            anchors.horizontalCenter: parent.horizontalCenter
            Label {
                id: hChipLabel
                anchors.centerIn: parent
                text: "Sinalização horizontal: " + panel.currentConditionLabel()
                color: "white"
                font.pixelSize: 12
                font.bold: true
            }
        }

        Rectangle {
            visible: panel.currentLinearName() !== ""
            height: 30
            width: lChipLabel.implicitWidth + 32
            radius: 15
            color: "#D0101A33"
            border.width: 2
            border.color: "#00ACC1"
            anchors.horizontalCenter: parent.horizontalCenter
            Label {
                id: lChipLabel
                anchors.centerIn: parent
                text: "Ciclovia: " + panel.currentLinearName()
                color: "white"
                font.pixelSize: 12
                font.bold: true
            }
        }
    }

    // #####################################################################
    //  RETRATO
    // #####################################################################

    // ---- Esquerda: linhas (colunas verticais, "encerrar" ao lado do grupo) ----
    Flickable {
        id: leftDock
        visible: !panel.isLandscape
        anchors.left: parent.left
        anchors.bottom: parent.bottom
        anchors.leftMargin: panel.safeLeftMargin
        anchors.bottomMargin: panel.safeBottomMargin
        width: panel.buttonSize * 2 + panel.stopGap
        height: Math.min(leftCol.implicitHeight,
                         panel.height - panel.safeTopMargin - panel.safeBottomMargin - 12)
        contentWidth: width
        contentHeight: leftCol.implicitHeight
        interactive: contentHeight > height
        boundsBehavior: Flickable.StopAtBounds
        clip: true
        z: 7002

        Column {
            id: leftCol
            width: leftDock.width
            spacing: panel.dockSpacing

            Item {
                id: horizontalGroup
                width: leftCol.width
                height: horizontalCol.implicitHeight

                Column {
                    id: horizontalCol
                    width: panel.buttonSize
                    spacing: panel.dockSpacing

                    Repeater {
                        model: panel.horizontalConditions

                        DockButton {
                            required property var modelData
                            label: modelData.rotulo
                            imageSource: panel.conditionImage(modelData.valor)
                            iconSource: panel.iconHorizontal
                            accent: panel.conditionColor(modelData.valor)
                            active: panel.currentConditionValue() === modelData.valor
                            dimmed: panel.currentConditionValue() !== "" && !active
                            onClicked: {
                                panel.clearMessage();
                                panel.horizontalConditionRequested(modelData);
                            }
                        }
                    }
                }

                DockButton {
                    x: panel.buttonSize + panel.stopGap
                    y: (horizontalGroup.height - height) / 2
                    visible: !!(horizontalTracker && horizontalTracker.active)
                    isStop: true
                    imageSource: panel.imgParar
                    accent: "#E53935"
                    label: "Encerrar sinalização horizontal"
                    onClicked: panel.horizontalFinishRequested()
                }
            }

            Divider { visible: panel.linearButtons.length > 0 }

            Item {
                id: cycleGroup
                width: leftCol.width
                height: cycleCol.implicitHeight

                Column {
                    id: cycleCol
                    width: panel.buttonSize
                    spacing: panel.dockSpacing

                    Repeater {
                        model: panel.linearButtons

                        DockButton {
                            required property var modelData
                            label: modelData.nome
                            imageSource: panel.linearImage(modelData)
                            iconSource: panel.linearImage(modelData).toString() !== "" ? "" : panel.iconCycle
                            accent: "#00ACC1"
                            active: panel.currentLinearName() === modelData.nome
                            dimmed: panel.currentLinearName() !== "" && !active
                            onClicked: {
                                panel.clearMessage();
                                panel.linearRequested(modelData);
                            }
                        }
                    }
                }

                DockButton {
                    x: panel.buttonSize + panel.stopGap
                    y: (cycleGroup.height - height) / 2
                    visible: !!(linearTracker && linearTracker.active)
                    isStop: true
                    imageSource: panel.imgParar
                    accent: "#E53935"
                    label: "Encerrar estrutura cicloviária"
                    onClicked: panel.linearFinishRequested()
                }
            }
        }
    }

    // ---- Direita: elementos pontuais (uma cor por grupo) ----
    Flickable {
        id: rightDock
        visible: !panel.isLandscape
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        anchors.rightMargin: panel.safeRightMargin
        anchors.bottomMargin: panel.safeBottomMargin
        width: panel.buttonSize
        height: Math.min(rightCol.implicitHeight,
                         panel.height - panel.safeTopMargin - panel.safeBottomMargin - 12)
        contentWidth: width
        contentHeight: rightCol.implicitHeight
        interactive: contentHeight > height
        boundsBehavior: Flickable.StopAtBounds
        clip: true
        z: 7002

        Column {
            id: rightCol
            width: rightDock.width
            spacing: panel.dockSpacing

            Repeater {
                model: panel.pointGroups()

                Column {
                    id: family
                    required property var modelData
                    required property int index
                    width: rightCol.width
                    spacing: panel.dockSpacing

                    Divider { visible: family.index > 0 }

                    Repeater {
                        model: family.modelData.botoes

                        DockButton {
                            required property var modelData
                            rightAligned: true
                            label: modelData.nome
                            imageSource: panel.pointImage(modelData)
                            iconSource: family.modelData.icone
                            accent: family.modelData.cor
                            enabled: !(pointTracker && pointTracker.active)
                            onClicked: {
                                panel.clearMessage();
                                panel.pointRequested(modelData);
                            }
                        }
                    }
                }
            }
        }
    }

    // #####################################################################
    //  PAISAGEM: composição compacta
    //  - famílias lineares empilhadas e justificadas à esquerda;
    //  - famílias pontuais empilhadas e justificadas à direita;
    //  - espaços mínimos entre grupos para caber tudo na tela;
    //  - leve deslocamento horizontal entre grupos pontuais (inclinação).
    // #####################################################################

    // ---- Esquerda: lineares em duas faixas compactas ----
    Flickable {
        id: leftDockL
        visible: panel.isLandscape
        anchors.left: parent.left
        anchors.bottom: parent.bottom
        anchors.leftMargin: panel.safeLeftMargin
        anchors.bottomMargin: panel.safeBottomMargin
        width: Math.min(leftLandscapeContent.implicitWidth,
                        Math.max(panel.buttonSize * 2,
                                 panel.width * 0.54))
        height: Math.min(leftLandscapeContent.implicitHeight,
                         panel.height - panel.safeTopMargin - panel.safeBottomMargin - 8)
        contentWidth: leftLandscapeContent.implicitWidth
        contentHeight: leftLandscapeContent.implicitHeight
        interactive: contentWidth > width || contentHeight > height
        boundsBehavior: Flickable.StopAtBounds
        clip: false
        z: 7002

        Column {
            id: leftLandscapeContent
            spacing: panel.landscapeGroupGap

            // Sinalização horizontal: grade 2x2 estilo controle de game.
            Row {
                id: horizontalLandscapeRow
                spacing: panel.landscapeButtonGap

                Grid {
                    id: horizontalLandscapeGrid
                    columns: 2
                    rows: 2
                    columnSpacing: panel.landscapeButtonGap
                    rowSpacing: panel.landscapeButtonGap

                    Repeater {
                        model: panel.horizontalConditions

                        DockButton {
                            required property var modelData
                            label: modelData.rotulo
                            imageSource: panel.conditionImage(modelData.valor)
                            iconSource: panel.iconHorizontal
                            accent: panel.conditionColor(modelData.valor)
                            active: panel.currentConditionValue() === modelData.valor
                            dimmed: panel.currentConditionValue() !== "" && !active
                            onClicked: {
                                panel.clearMessage();
                                panel.horizontalConditionRequested(modelData);
                            }
                        }
                    }
                }

                DockButton {
                    anchors.verticalCenter: horizontalLandscapeGrid.verticalCenter
                    visible: !!(horizontalTracker && horizontalTracker.active)
                    isStop: true
                    imageSource: panel.imgParar
                    accent: "#E53935"
                    label: "Encerrar sinalização horizontal"
                    onClicked: panel.horizontalFinishRequested()
                }
            }

            // Estrutura cicloviária imediatamente abaixo, sem grande separação.
            Row {
                id: cycleLandscapeRow
                spacing: panel.landscapeButtonGap

                Repeater {
                    model: panel.linearButtons

                    DockButton {
                        required property var modelData
                        label: modelData.nome
                        imageSource: panel.linearImage(modelData)
                        iconSource: panel.linearImage(modelData).toString() !== "" ? "" : panel.iconCycle
                        accent: "#00ACC1"
                        active: panel.currentLinearName() === modelData.nome
                        dimmed: panel.currentLinearName() !== "" && !active
                        onClicked: {
                            panel.clearMessage();
                            panel.linearRequested(modelData);
                        }
                    }
                }

                DockButton {
                    visible: !!(linearTracker && linearTracker.active)
                    isStop: true
                    imageSource: panel.imgParar
                    accent: "#E53935"
                    label: "Encerrar estrutura cicloviária"
                    onClicked: panel.linearFinishRequested()
                }
            }
        }
    }

    // ---- Direita: categorias pontuais uma sobre a outra ----
    Flickable {
        id: rightDockL
        visible: panel.isLandscape
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        anchors.rightMargin: panel.safeRightMargin
        anchors.bottomMargin: panel.safeBottomMargin
        width: Math.min(panel.width * 0.42,
                        panel.buttonSize * 3
                        + panel.landscapeButtonGap * 2
                        + panel.landscapeGroupTilt * 2 + 18)
        height: Math.min(rightLandscapeStack.implicitHeight,
                         panel.height - panel.safeTopMargin - panel.safeBottomMargin - 8)
        contentWidth: width
        contentHeight: rightLandscapeStack.implicitHeight
        interactive: contentHeight > height
        boundsBehavior: Flickable.StopAtBounds
        clip: false
        z: 7002

        Column {
            id: rightLandscapeStack
            width: rightDockL.width
            spacing: panel.landscapeGroupGap

            Repeater {
                model: panel.isLandscape ? panel.pointGroups() : []

                Item {
                    id: landscapePointFamily
                    required property var modelData
                    required property int index
                    width: rightLandscapeStack.width
                    height: panel.buttonSize

                    // Pequeno marcador translúcido da categoria. Ele acompanha a
                    // inclinação, sem criar uma caixa de fundo sobre o mapa.
                    Rectangle {
                        id: familyMarker
                        width: 5
                        height: Math.round(panel.buttonSize * 0.56)
                        radius: width / 2
                        color: landscapePointFamily.modelData.cor
                        opacity: 0.72
                        anchors.right: parent.right
                        anchors.rightMargin: landscapePointFamily.index * panel.landscapeGroupTilt
                        anchors.verticalCenter: parent.verticalCenter
                    }

                    Row {
                        id: landscapePointRow
                        spacing: panel.landscapeButtonGap
                        anchors.right: familyMarker.left
                        anchors.rightMargin: 5
                        anchors.verticalCenter: parent.verticalCenter

                        Repeater {
                            model: landscapePointFamily.modelData.botoes

                            DockButton {
                                required property var modelData
                                rightAligned: true
                                label: modelData.nome
                                imageSource: panel.pointImage(modelData)
                                iconSource: landscapePointFamily.modelData.icone
                                accent: landscapePointFamily.modelData.cor
                                enabled: !(pointTracker && pointTracker.active)
                                onClicked: {
                                    panel.clearMessage();
                                    panel.pointRequested(modelData);
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // =====================================================================
    // Etiqueta com o nome completo (nível do painel, não é cortada pelos docks)
    //   retrato: ao lado do botão | paisagem: acima do botão
    // =====================================================================
    Rectangle {
        id: hintPill
        visible: panel.hintText.length > 0
        z: 7020
        height: 34
        width: Math.min(hintLabel.implicitWidth + 26, panel.width * 0.55)
        radius: 17
        color: "#F0101A33"
        border.width: 1
        border.color: "#66FFFFFF"
        y: panel.isLandscape ? Math.max(4, panel.hintTopY - height - 8)
                             : panel.hintCenterY - height / 2
        x: panel.isLandscape
           ? Math.max(6, Math.min(panel.width - width - 6,
                                  panel.hintAnchorX + panel.hintW / 2 - width / 2))
           : (panel.hintOnLeft ? panel.hintAnchorX - width - 10
                               : panel.hintAnchorX + panel.hintW + 10)

        Label {
            id: hintLabel
            anchors.fill: parent
            anchors.leftMargin: 13
            anchors.rightMargin: 13
            text: panel.hintText
            color: "white"
            font.pixelSize: 13
            font.bold: true
            elide: Text.ElideRight
            verticalAlignment: Text.AlignVCenter
            horizontalAlignment: Text.AlignHCenter
        }
    }
}
