import QtQuick
import QtQml
import org.qfield.core
import org.qfield.gui

import "GeometryService.js" as GeometryService

Item {
    id: controller
    width: 0
    height: 0
    visible: false

    property var positioning: null
    property var targetLayer: null
    property var buttonConfig: null
    property var gpsConfig: ({})
    property var saveHandler: null

    property bool active: false
    property bool waitingPoint: false
    property var points: []
    property var lastPositionInfo: null
    property string statusText: ""
    property double currentAccuracy: -1
    property int rejectedAccuracy: 0

    signal errorOccurred(string message)
    signal featureSaved(string label)
    signal segmentSaved(string label)

    function reset() {
        active = false;
        waitingPoint = false;
        targetLayer = null;
        buttonConfig = null;
        points = [];
        lastPositionInfo = null;
        statusText = "";
        currentAccuracy = -1;
        rejectedAccuracy = 0;
    }

    function _ensureGpsActive() {
        if (!positioning) {
            errorOccurred("Serviço de posicionamento do QField indisponível.");
            return false;
        }
        if (!positioning.active) {
            positioning.active = true;
        }
        return true;
    }

    function begin(layerObject, cfg, gps) {
        reset();
        targetLayer = layerObject;
        buttonConfig = cfg;
        gpsConfig = gps || ({});

        if (!_ensureGpsActive()) {
            return false;
        }

        active = true;
        waitingPoint = false;
        statusText = "Coleta linear ativa";

        // Registra o ponto inicial imediatamente. Depois disso, o Timer abaixo
        // amostra a posição a cada intervalo configurado (1 s por padrão).
        captureTimedPosition();
        return true;
    }

    function cancel() {
        if (active) {
            reset();
        }
    }

    function _fixAcceptable(info) {
        if (!info || !info.latitudeValid || !info.longitudeValid || !info.isValid) {
            statusText = "Aguardando fix GNSS válido…";
            return false;
        }

        currentAccuracy = info.haccValid ? Number(info.hacc) : -1;

        // Por padrão a coleta linear é puramente temporal: um ponto por segundo.
        // O filtro de precisão só é aplicado se for explicitamente habilitado
        // na configuração GPS. Assim, uma precisão momentaneamente pior não
        // impede a linha de começar ou cria longos vazios no rastreamento.
        var requireAcc = gpsConfig.exigirPrecisaoValida === true;
        var maxAcc = Number(gpsConfig.precisaoMaximaM || 0);

        if (requireAcc && !info.haccValid) {
            rejectedAccuracy++;
            statusText = "Fix GNSS sem precisão horizontal; amostra ignorada.";
            return false;
        }

        if (maxAcc > 0 && info.haccValid && Number(info.hacc) > maxAcc) {
            rejectedAccuracy++;
            statusText = "Precisão GNSS insuficiente; amostra ignorada.";
            return false;
        }

        return true;
    }

    function _pointFromInfo(info) {
        return {
            lat: Number(info.latitude),
            lon: Number(info.longitude),
            hacc: info.haccValid ? Number(info.hacc) : null,
            timestampMs: Date.now()
        };
    }

    // Amostragem exclusivamente temporal: nenhum critério de distância mínima
    // ou máxima é aplicado. A cada disparo do Timer, o fix corrente é adicionado
    // caso seja válido e atenda apenas ao filtro de precisão GNSS.
    function captureTimedPosition() {
        if (!active || !positioning) {
            return false;
        }

        var info = positioning.positionInformation;
        if (!_fixAcceptable(info)) {
            return false;
        }

        var p = _pointFromInfo(info);
        var novaLista = points.slice(0);
        novaLista.push(p);
        points = novaLista;
        lastPositionInfo = info;
        statusText = "Coleta linear ativa";
        return true;
    }

    function _captureBoundaryPoint() {
        if (!positioning) {
            return null;
        }

        var info = positioning.positionInformation;
        if (!_fixAcceptable(info)) {
            return null;
        }

        var p = _pointFromInfo(info);
        var novaLista = points.slice(0);
        novaLista.push(p);
        points = novaLista;
        lastPositionInfo = info;
        return p;
    }

    function _toLayerGeometry(wkt) {
        var sourceGeometry = QfGeometryUtils.createGeometryFromWkt(wkt);
        return QfGeometryUtils.reprojectGeometry(
            sourceGeometry,
            QfCoordinateReferenceSystemUtils.wgs84Crs(),
            targetLayer.crs
        );
    }

    function _saveCurrentLineSegment() {
        if (!active || points.length < 2) {
            return false;
        }

        var finalPoints = GeometryService.simplificar(points, Number(gpsConfig.simplificacaoM || 0));
        if (finalPoints.length < 2) {
            errorOccurred("A geometria ficou com menos de dois pontos válidos.");
            return false;
        }

        var geometry = _toLayerGeometry(GeometryService.wktLinha(finalPoints));
        if (!saveHandler) {
            errorOccurred("Rotina de salvamento do plugin não está disponível.");
            return false;
        }

        var lastPoint = finalPoints[finalPoints.length - 1];
        return saveHandler(targetLayer, buttonConfig, geometry, lastPositionInfo, lastPoint);
    }

    // Ao mudar o estado/tipo, fecha-se o trecho atual e o último ponto passa a
    // ser o primeiro do trecho seguinte. O rastreamento temporal continua ativo.
    function switchSegment(newCfg) {
        if (!active) {
            return false;
        }

        _captureBoundaryPoint();

        var seed = points.length > 0 ? points[points.length - 1] : null;
        var oldLabel = buttonConfig ? buttonConfig.nome : "Trecho";

        if (points.length >= 2) {
            if (!_saveCurrentLineSegment()) {
                errorOccurred("Não foi possível salvar o trecho atual; a classificação não foi alterada.");
                return false;
            }
            segmentSaved(oldLabel);
        }

        buttonConfig = newCfg;
        points = seed ? [seed] : [];
        statusText = "Coleta linear ativa";
        return true;
    }

    function finish() {
        if (!active) {
            return false;
        }

        _captureBoundaryPoint();

        if (points.length < 2) {
            // Encerramento silencioso de um trecho curto: nada é salvo e a coleta
            // é simplesmente finalizada, sem mensagem de "dados insuficientes".
            reset();
            return true;
        }

        var label = buttonConfig ? buttonConfig.nome : "Trecho linear";
        if (_saveCurrentLineSegment()) {
            reset();
            featureSaved(label);
            return true;
        }

        errorOccurred("Não foi possível gravar o trecho final. A coleta foi mantida para nova tentativa.");
        return false;
    }

    Timer {
        id: sampleTimer
        interval: Math.max(100, Number(controller.gpsConfig.intervaloMs || 1000))
        repeat: true
        running: controller.active
        triggeredOnStart: false
        onTriggered: controller.captureTimedPosition()
    }
}
