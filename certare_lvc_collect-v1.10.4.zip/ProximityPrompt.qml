import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qfield.gui

Item {
    id: prompt

    property var controller: null
    property bool projectActive: true
    readonly property bool isLandscape: width > height

    parent: iface.mainWindow().contentItem
    anchors.fill: parent
    visible: projectActive && controller && controller.promptActive
    enabled: visible
    z: 9800

    // Área transparente para impedir toques acidentais nos botões do plugin/mapa
    // enquanto a pergunta está sendo respondida.
    Rectangle {
        anchors.fill: parent
        color: "#22000000"

        MouseArea {
            anchors.fill: parent
            onClicked: function(mouse) { mouse.accepted = true; }
        }
    }

    Rectangle {
        id: card
        width: Math.min(parent.width - 28, prompt.isLandscape ? 520 : 420)
        height: content.implicitHeight + 28
        anchors.horizontalCenter: parent.horizontalCenter
        y: prompt.isLandscape ? 28 : Math.max(90, parent.height * 0.16)
        radius: 16
        color: "#E61D242B"
        border.width: 1
        border.color: "#55FFFFFF"

        ColumnLayout {
            id: content
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.top: parent.top
            anchors.margins: 14
            spacing: 9

            Label {
                Layout.fillWidth: true
                text: controller ? controller.currentLabel : "Elemento"
                color: "white"
                font.bold: true
                font.pixelSize: 20
                wrapMode: Text.WordWrap
                horizontalAlignment: Text.AlignHCenter
            }

            Label {
                Layout.fillWidth: true
                visible: controller && controller.currentSecondary.length > 0
                text: controller ? controller.currentSecondary : ""
                color: "#C9FFFFFF"
                font.pixelSize: 13
                wrapMode: Text.WordWrap
                horizontalAlignment: Text.AlignHCenter
            }

            Label {
                Layout.fillWidth: true
                text: "Este elemento ainda existe?"
                color: "white"
                font.pixelSize: 17
                wrapMode: Text.WordWrap
                horizontalAlignment: Text.AlignHCenter
            }

            RowLayout {
                Layout.fillWidth: true
                spacing: 8

                Button {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 54
                    text: "SIM"
                    font.bold: true
                    font.pixelSize: 17
                    background: Rectangle { radius: 10; color: "#CC2E7D32" }
                    contentItem: Label {
                        text: parent.text
                        color: "white"
                        font: parent.font
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                    }
                    onClicked: controller.answerExists(true)
                }

                Button {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 54
                    text: "NÃO"
                    font.bold: true
                    font.pixelSize: 17
                    background: Rectangle { radius: 10; color: "#CCC62828" }
                    contentItem: Label {
                        text: parent.text
                        color: "white"
                        font: parent.font
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                    }
                    onClicked: controller.answerExists(false)
                }
            }

            Button {
                Layout.fillWidth: true
                Layout.preferredHeight: 44
                text: "DEPOIS"
                font.pixelSize: 15
                background: Rectangle { radius: 10; color: "#B05F6B73" }
                contentItem: Label {
                    text: parent.text
                    color: "white"
                    font: parent.font
                    horizontalAlignment: Text.AlignHCenter
                    verticalAlignment: Text.AlignVCenter
                }
                onClicked: controller.postpone()
            }
        }
    }
}
