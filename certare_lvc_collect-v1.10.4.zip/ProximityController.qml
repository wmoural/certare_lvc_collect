import QtQuick
import org.qfield.core
import org.qfield.gui
import org.qgis

Item {
    id: controller
    width: 0
    height: 0
    visible: false

    property var positioning: null
    property var project: null
    property var runtimeConfig: ({})
    property var notifyHandler: null
    property bool suspended: false

    property bool promptActive: false
    property var currentFeature: null
    property var currentLayer: null
    property string currentFeatureKey: ""
    property string currentLabel: ""
    property string currentSecondary: ""
    property real currentDistanceM: -1

    // Memória apenas da sessão atual do plugin.
    // SIM/NÃO: não pergunta novamente até reiniciar o plugin.
    // DEPOIS: não pergunta enquanto o usuário permanecer no raio; rearma ao sair.
    property var handledIds: ({})
    property var postponedIds: ({})
    property bool configurationWarningShown: false

    readonly property bool enabled: runtimeConfig
                                    && runtimeConfig.habilitado === true
                                    && runtimeConfig.layerName
                                    && runtimeConfig.confirmationField

    function _notify(text, isError) {
        if (notifyHandler && text) {
            notifyHandler(text, isError === true);
        }
    }

    function resetSession() {
        promptActive = false;
        currentFeature = null;
        currentLayer = null;
        currentFeatureKey = "";
        currentLabel = "";
        currentSecondary = "";
        currentDistanceM = -1;
        handledIds = ({});
        postponedIds = ({});
        configurationWarningShown = false;
    }

    function _featureKey(feature) {
        if (!feature) return "";
        try {
            return String(feature.id);
        } catch (e) {
            return "";
        }
    }

    // Marca uma feature como já verificada na sessão. Usado também para
    // pontos criados pelo próprio plugin, evitando que o monitor pergunte
    // imediatamente se o elemento recém-coletado ainda existe.
    function markFeatureHandled(feature) {
        var key = _featureKey(feature);
        if (!key) return false;

        var nextHandled = ({});
        for (var existingKey in handledIds) {
            nextHandled[existingKey] = handledIds[existingKey];
        }
        nextHandled[key] = true;
        handledIds = nextHandled;

        // Caso a mesma feature estivesse temporariamente em DEPOIS, remove-a
        // dessa lista para prevalecer o estado definitivo de ignorada.
        if (postponedIds[key] === true) {
            var nextPostponed = ({});
            for (var postponedKey in postponedIds) {
                if (postponedKey !== key) {
                    nextPostponed[postponedKey] = postponedIds[postponedKey];
                }
            }
            postponedIds = nextPostponed;
        }

        if (promptActive && currentFeatureKey === key) {
            _closePrompt();
        }
        return true;
    }

    function _distanceM(lat1, lon1, lat2, lon2) {
        var R = 6371008.8;
        var toRad = Math.PI / 180.0;
        var p1 = Number(lat1) * toRad;
        var p2 = Number(lat2) * toRad;
        var dp = (Number(lat2) - Number(lat1)) * toRad;
        var dl = (Number(lon2) - Number(lon1)) * toRad;
        var a = Math.sin(dp / 2) * Math.sin(dp / 2)
              + Math.cos(p1) * Math.cos(p2)
              * Math.sin(dl / 2) * Math.sin(dl / 2);
        return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    }

    function _candidateDistanceM(feature, layer, userLat, userLon) {
        try {
            if (!feature || !feature.geometry) return -1;
            var center = QfGeometryUtils.centroid(feature.geometry);
            var wgs = QfGeometryUtils.reprojectPoint(
                center,
                layer.crs,
                QfCoordinateReferenceSystemUtils.wgs84Crs()
            );
            return _distanceM(userLat, userLon, Number(wgs.y), Number(wgs.x));
        } catch (e) {
            return -1;
        }
    }

    function _labelForFeature(feature, layer) {
        var label = "";
        if (runtimeConfig.labelField) {
            try {
                var v = feature.attribute(runtimeConfig.labelField);
                if (v !== null && v !== undefined && String(v).length > 0) {
                    label = String(v);
                }
            } catch (e) {}
        }
        if (!label) {
            try { label = QfFeatureUtils.displayName(layer, feature); } catch (e2) {}
        }
        return label || "Elemento";
    }

    function _secondaryForFeature(feature) {
        if (!runtimeConfig.secondaryField) return "";
        try {
            var v = feature.attribute(runtimeConfig.secondaryField);
            if (v !== null && v !== undefined) return String(v);
        } catch (e) {}
        return "";
    }

    function _isNullLike(value) {
        if (value === null || value === undefined) return true;

        // Campos DateTime NULL normalmente chegam ao QML como null/undefined.
        // Os testes abaixo também cobrem providers que exponham um valor inválido
        // ou vazio para representar NULL.
        try {
            if (value instanceof Date) {
                return isNaN(value.getTime());
            }
        } catch (e) {}

        try {
            var s = String(value).trim().toLowerCase();
            return s === "" || s === "null" || s === "undefined"
                    || s === "invalid" || s === "invalid date"
                    || s === "qvariant(invalid)";
        } catch (e2) {
            return false;
        }
    }

    function _passesNullFilter(feature) {
        var fieldName = String(runtimeConfig.nullFilterField || "");
        if (!fieldName) return true;
        try {
            return _isNullLike(feature.attribute(fieldName));
        } catch (e) {
            return false;
        }
    }

    function _validateCandidateFields(feature) {
        if (!feature || !feature.fields) return false;
        var idx = feature.fields.lookupField(runtimeConfig.confirmationField);
        if (idx < 0) {
            if (!configurationWarningShown) {
                configurationWarningShown = true;
                _notify("Campo de proximidade não encontrado: " + runtimeConfig.confirmationField, true);
            }
            return false;
        }

        var nullField = String(runtimeConfig.nullFilterField || "");
        if (nullField && feature.fields.lookupField(nullField) < 0) {
            if (!configurationWarningShown) {
                configurationWarningShown = true;
                _notify("Campo do filtro de proximidade não encontrado: " + nullField, true);
            }
            return false;
        }

        var updateDateField = String(runtimeConfig.updateDateField || "");
        if (updateDateField && feature.fields.lookupField(updateDateField) < 0) {
            if (!configurationWarningShown) {
                configurationWarningShown = true;
                _notify("Campo de data da proximidade não encontrado: " + updateDateField, true);
            }
            return false;
        }
        return true;
    }

    function scan() {
        if (!enabled || suspended || promptActive || !positioning || !project) return;

        if (!positioning.active) positioning.active = true;
        var info = positioning.positionInformation;
        if (!info || !info.isValid || !info.latitudeValid || !info.longitudeValid) return;

        var layers = project.mapLayersByName(String(runtimeConfig.layerName));
        if (!layers || layers.length !== 1) {
            if (!configurationWarningShown) {
                configurationWarningShown = true;
                _notify("Camada de proximidade não encontrada: " + runtimeConfig.layerName, true);
            }
            return;
        }

        var layer = layers[0];
        if (layer.geometryType() !== Qgis.GeometryType.Point) return;

        var radius = Math.max(1, Number(runtimeConfig.raioMetros || 15));
        var lat = Number(info.latitude);
        var lon = Number(info.longitude);
        var latDelta = radius / 111320.0;
        var cosLat = Math.max(0.15, Math.abs(Math.cos(lat * Math.PI / 180.0)));
        var lonDelta = radius / (111320.0 * cosLat);

        var p1 = QfGeometryUtils.point(lon - lonDelta, lat - latDelta);
        var p2 = QfGeometryUtils.point(lon + lonDelta, lat + latDelta);
        var wgsRect = QfGeometryUtils.createRectangleFromPoints(p1, p2);
        var layerRect = QfGeometryUtils.reprojectRectangle(
            wgsRect,
            QfCoordinateReferenceSystemUtils.wgs84Crs(),
            layer.crs
        );

        var iterator = QfLayerUtils.createFeatureIteratorFromRectangle(layer, layerRect);
        var nearestFeature = null;
        var nearestKey = "";
        var nearestDistance = Number.POSITIVE_INFINITY;
        var postponedStillNearby = ({});

        try {
            while (iterator.hasNext()) {
                var feature = iterator.next();
                if (!_validateCandidateFields(feature)) continue;

                // Regra persistente de campanha: somente pontos com DATA COLETA
                // (ou outro campo configurado) NULL entram na checagem. Assim,
                // pontos recém-criados, que recebem data/hora, são ignorados.
                if (!_passesNullFilter(feature)) continue;

                var key = _featureKey(feature);
                if (!key) continue;

                var d = _candidateDistanceM(feature, layer, lat, lon);
                if (d < 0 || d > radius) continue;

                if (postponedIds[key] === true) {
                    postponedStillNearby[key] = true;
                    continue;
                }
                if (handledIds[key] === true) continue;

                if (d < nearestDistance) {
                    nearestFeature = feature;
                    nearestKey = key;
                    nearestDistance = d;
                }
            }
        } finally {
            iterator.close();
        }

        // Um item marcado como DEPOIS é rearmado quando sai completamente do raio.
        var rearmedPostponed = ({});
        for (var oldKey in postponedIds) {
            if (postponedStillNearby[oldKey] === true) {
                rearmedPostponed[oldKey] = true;
            }
        }
        postponedIds = rearmedPostponed;

        if (nearestFeature !== null) {
            currentFeature = nearestFeature;
            currentLayer = layer;
            currentFeatureKey = nearestKey;
            currentLabel = _labelForFeature(nearestFeature, layer);
            currentSecondary = _secondaryForFeature(nearestFeature);
            currentDistanceM = nearestDistance;
            promptActive = true;
        }
    }

    function _closePrompt() {
        promptActive = false;
        currentFeature = null;
        currentLayer = null;
        currentFeatureKey = "";
        currentLabel = "";
        currentSecondary = "";
        currentDistanceM = -1;
    }

    function postpone() {
        if (!promptActive || !currentFeatureKey) return;
        var next = ({});
        for (var k in postponedIds) next[k] = postponedIds[k];
        next[currentFeatureKey] = true;
        postponedIds = next;
        _closePrompt();
    }

    function answerExists(existsValue) {
        if (!promptActive || !currentFeature || !currentLayer) return false;

        var fieldName = String(runtimeConfig.confirmationField || "");
        var fieldIndex = currentFeature.fields.lookupField(fieldName);
        if (fieldIndex < 0) {
            _notify("Campo não encontrado: " + fieldName, true);
            return false;
        }

        var newValue = existsValue ? runtimeConfig.valorSim : runtimeConfig.valorNao;
        var oldValue = currentFeature.attribute(fieldName);
        var updateDateField = String(runtimeConfig.updateDateField || "");
        var updateDateIndex = updateDateField ? currentFeature.fields.lookupField(updateDateField) : -1;
        var oldDateValue = updateDateIndex >= 0 ? currentFeature.attribute(updateDateField) : null;
        var nowValue = new Date();
        var startedHere = false;

        try {
            if (!currentLayer.isEditable || !currentLayer.isEditable()) {
                if (!currentLayer.startEditing()) {
                    _notify("A camada ‘" + runtimeConfig.layerName + "’ não pôde entrar em edição.", true);
                    return false;
                }
                startedHere = true;
            }

            if (!currentLayer.changeAttributeValue(currentFeature.id, fieldIndex, newValue, oldValue)) {
                if (startedHere && currentLayer.isEditable && currentLayer.isEditable()) currentLayer.rollBack();
                _notify("Não foi possível atualizar ‘" + fieldName + "’.", true);
                return false;
            }

            if (updateDateIndex >= 0) {
                if (!currentLayer.changeAttributeValue(currentFeature.id, updateDateIndex, nowValue, oldDateValue)) {
                    if (startedHere && currentLayer.isEditable && currentLayer.isEditable()) {
                        currentLayer.rollBack();
                    } else {
                        // A camada já estava em edição por outro fluxo. Reverte somente
                        // a alteração deste plugin, sem descartar outras edições.
                        currentLayer.changeAttributeValue(currentFeature.id, fieldIndex, oldValue, newValue);
                    }
                    _notify("Não foi possível atualizar ‘" + updateDateField + "’.", true);
                    return false;
                }
            }

            if (startedHere && !currentLayer.commitChanges()) {
                var details = "";
                if (currentLayer.commitErrors) {
                    var errors = currentLayer.commitErrors();
                    if (errors && errors.length) details = " " + errors.join(" | ");
                }
                if (currentLayer.isEditable && currentLayer.isEditable()) currentLayer.rollBack();
                _notify("Falha ao salvar a confirmação." + details, true);
                return false;
            }

            if (currentLayer.triggerRepaint) currentLayer.triggerRepaint();
            var canvas = iface.mapCanvas();
            if (canvas && canvas.refresh) canvas.refresh(false);

            var nextHandled = ({});
            for (var key in handledIds) nextHandled[key] = handledIds[key];
            nextHandled[currentFeatureKey] = true;
            handledIds = nextHandled;
            _closePrompt();
            return true;
        } catch (e) {
            if (startedHere && currentLayer && currentLayer.isEditable && currentLayer.isEditable()) {
                currentLayer.rollBack();
            }
            _notify("Erro ao atualizar a existência do elemento.", true);
            return false;
        }
    }

    Timer {
        id: scanTimer
        interval: Math.max(300, Number(controller.runtimeConfig.intervaloMs || 1000))
        repeat: true
        running: controller.enabled && !controller.suspended && !controller.promptActive
        triggeredOnStart: false
        onTriggered: controller.scan()
    }

    Component.onCompleted: {
        if (positioning && !positioning.active) positioning.active = true;
    }
}
